# Evaluation & Viva Defense Guide (Guideline 8)

This guide summarizes the key implementation walkthroughs for your GDG evaluation interview:

1. **Walkthrough 1 — Live Compiler X-Ray (`src/engine/lexer.ts` & `src/engine/parser.ts`):**
   - Select cell `F2` (`=SUM(B2:E2)`) or `I6` (`=CONCAT("ARR: $", ROUND(F6*1.15, 0), "K")`) and open the **Lexer & AST** tab in the right split-pane to show how character spans flow from tokens into AST nodes.
2. **Walkthrough 2 — Caret Error Diagnostics & Levenshtein Auto-Fix:**
   - Click **"2. Caret Error Diagnostics Lab"** in the top header and click through cells `C2..C6`. Show how `C2` (`=SUM(B2, B3`) matches the exact GDG prompt specification and how clicking **Apply Fix** repairs the formula in place.
3. **Walkthrough 3 — Direct & Indirect Cycle Isolation (`src/engine/dag.ts`):**
   - Click **"3. Circular Reference (#CYCLE!) Lab"** to show a 4-node loop (`B2 → C2 → D2 → E2 → B2`) rendered in crimson in the SVG Dependency Graph while `F2` continues to evaluate normally.
4. **Walkthrough 4 — 10,000-Cell Virtualization & Incremental Recalc:**
   - Click **"4. 10,000-Cell Stress Test"** and edit cell `A2` vs `A100`. Point out the **Live Telemetry HUD** showing `19 evaluated / 817 skipped` (`~1.8 ms`) vs `0 evaluated / 836 skipped` (`~1.3 ms`) while DOM nodes remain capped at `~150`.

// ============================================================================
// 2. GRID COORDINATE HELPERS & REFERENCE SHIFTING
// ============================================================================

export function colIndexToLabel(index: number): string {
  let label = '';
  let n = index;
  while (n >= 0) {
    label = String.fromCharCode((n % 26) + 65) + label;
    n = Math.floor(n / 26) - 1;
  }
  return label;
}

export function colLabelToIndex(label: string): number {
  let result = 0;
  const clean = label.toUpperCase();
  for (let i = 0; i < clean.length; i++) {
    result = result * 26 + (clean.charCodeAt(i) - 64);
  }
  return result - 1;
}

export function parseCellId(cellId: string): { col: number; row: number; absCol: boolean; absRow: boolean } | null {
  const match = /^(\$?)([A-Z]{1,3})(\$?)([1-9][0-9]*)$/i.exec(cellId.trim());
  if (!match) return null;
  const absCol = match[1] === '$';
  const col = colLabelToIndex(match[2]);
  const absRow = match[3] === '$';
  const row = parseInt(match[4], 10) - 1;
  if (col < 0 || row < 0) return null;
  return { col, row, absCol, absRow };
}

export function normalizeCellId(cellId: string): string {
  const parsed = parseCellId(cellId);
  if (!parsed) return cellId.toUpperCase();
  return `${colIndexToLabel(parsed.col)}${parsed.row + 1}`;
}

export function expandRange(startId: string, endId: string, maxCells = 15000): { cells: string[]; inverted: boolean; rowCount: number; colCount: number } {
  const start = parseCellId(startId);
  const end = parseCellId(endId);
  if (!start || !end) return { cells: [], inverted: false, rowCount: 0, colCount: 0 };

  const inverted = start.col > end.col || start.row > end.row;
  const minCol = Math.min(start.col, end.col);
  const maxCol = Math.max(start.col, end.col);
  const minRow = Math.min(start.row, end.row);
  const maxRow = Math.max(start.row, end.row);

  const cells: string[] = [];
  const rowCount = maxRow - minRow + 1;
  const colCount = maxCol - minCol + 1;

  for (let r = minRow; r <= maxRow; r++) {
    for (let c = minCol; c <= maxCol; c++) {
      cells.push(`${colIndexToLabel(c)}${r + 1}`);
      if (cells.length >= maxCells) return { cells, inverted, rowCount, colCount };
    }
  }
  return { cells, inverted, rowCount, colCount };
}

export function shiftFormulaReferences(formula: string, dCol: number, dRow: number): string {
  if (!formula.startsWith('=')) return formula;
  return formula.replace(/(\$?)([A-Z]{1,3})(\$?)([1-9][0-9]*)(?!\s*\()/gi, (full, dollarCol, colStr, dollarRow, rowStr) => {
    const absCol = dollarCol === '$';
    const absRow = dollarRow === '$';
    const colIdx = colLabelToIndex(colStr);
    const rowIdx = parseInt(rowStr, 10) - 1;
    const nextCol = absCol ? colIdx : Math.max(0, colIdx + dCol);
    const nextRow = absRow ? rowIdx : Math.max(0, rowIdx + dRow);
    return `${absCol ? '$' : ''}${colIndexToLabel(nextCol)}${absRow ? '$' : ''}${nextRow + 1}`;
  });
}


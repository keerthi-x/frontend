// ============================================================================
// 1. TYPES & INTERFACES — COMPILER-GRADE SPREADSHEET ENGINE
// ============================================================================

export type TokenType =
  | 'NUMBER'
  | 'STRING'
  | 'BOOLEAN'
  | 'CELL_REF'
  | 'FUNC'
  | 'OP'
  | 'COMPARE'
  | 'LPAREN'
  | 'RPAREN'
  | 'COMMA'
  | 'COLON'
  | 'EOF'
  | 'UNKNOWN';

export interface SourceSpan {
  start: number; // 0-indexed offset inside the raw formula (including '=')
  end: number;
}

export interface Token {
  type: TokenType;
  value: string;
  span: SourceSpan;
}

export type ASTNode =
  | { kind: 'NumberLiteral'; value: number; span: SourceSpan }
  | { kind: 'StringLiteral'; value: string; span: SourceSpan }
  | { kind: 'BooleanLiteral'; value: boolean; span: SourceSpan }
  | { kind: 'CellRef'; cellId: string; raw: string; absCol: boolean; absRow: boolean; span: SourceSpan }
  | { kind: 'RangeRef'; startCell: string; endCell: string; raw: string; span: SourceSpan }
  | { kind: 'UnaryExpr'; op: string; operand: ASTNode; span: SourceSpan }
  | { kind: 'BinaryExpr'; op: string; left: ASTNode; right: ASTNode; span: SourceSpan }
  | { kind: 'FunctionCall'; name: string; args: ASTNode[]; nameSpan: SourceSpan; span: SourceSpan }
  | { kind: 'ErrorNode'; message: string; span: SourceSpan };

export interface CaretDiagnostic {
  code: string;
  message: string;
  formula: string;
  caretStart: number; // 0-indexed position in formula string
  caretLength: number;
  suggestion: string;
  fixedFormula?: string;
}

export type CellValue = number | string | boolean | null;

export interface SparklineMeta {
  kind: 'sparkline' | 'bar';
  values: number[];
  color?: string;
  max?: number;
}

export interface EvaluatedCell {
  id: string;
  raw: string; // User input, e.g. "=SUM(A1:A5)" or "42"
  value: CellValue; // Computed result or error code like "#SYNTAX!", "#CYCLE!", "#DIV/0!", "#NAME?", "#REF!", "#VALUE!", "#N/A"
  display: string; // Formatted display string
  error: CaretDiagnostic | null;
  ast: ASTNode | null;
  tokens: Token[];
  dependencies: string[]; // Upstream cell IDs this cell reads from
  sparkline?: SparklineMeta;
  format?: 'currency' | 'percent' | 'number' | 'text';
  bold?: boolean;
  accent?: 'indigo' | 'emerald' | 'amber' | 'rose' | 'slate';
}

export interface RecalcTelemetry {
  recalcTimeMs: number;
  evaluatedCount: number;
  skippedCount: number;
  totalFormulaCells: number;
  evaluationOrder: string[];
  cyclesDetected: string[][];
  timestamp: string;
  triggerDescription: string;
}

export interface HistoryEntry {
  id: number;
  label: string;
  timestamp: string;
  rawCells: Record<string, string>;
  activeCell: string;
}


// ============================================================================
// 3. SUPPORTED FUNCTIONS CATALOG (40 BUILT-IN FUNCTIONS)
// ============================================================================

export interface FunctionDoc {
  name: string;
  category: 'Math' | 'Logic' | 'Lookup' | 'Statistical' | 'Text' | 'Visual & Finance';
  signature: string;
  description: string;
  example: string;
  minArgs: number;
  maxArgs: number;
}

export const FUNCTION_CATALOG: FunctionDoc[] = [
  // Math (12)
  { name: 'SUM', category: 'Math', signature: 'SUM(value1, [value2, ...])', description: 'Adds all numeric values in cells, ranges, or expressions.', example: '=SUM(B2:B6)', minArgs: 1, maxArgs: 99 },
  { name: 'AVERAGE', category: 'Math', signature: 'AVERAGE(value1, [value2, ...])', description: 'Returns the arithmetic mean of numeric arguments.', example: '=AVERAGE(B2:B6)', minArgs: 1, maxArgs: 99 },
  { name: 'MIN', category: 'Math', signature: 'MIN(value1, [value2, ...])', description: 'Returns the smallest numeric value in a dataset.', example: '=MIN(B2:B6)', minArgs: 1, maxArgs: 99 },
  { name: 'MAX', category: 'Math', signature: 'MAX(value1, [value2, ...])', description: 'Returns the largest numeric value in a dataset.', example: '=MAX(B2:B6)', minArgs: 1, maxArgs: 99 },
  { name: 'ABS', category: 'Math', signature: 'ABS(number)', description: 'Returns the absolute value of a number.', example: '=ABS(-42.5)', minArgs: 1, maxArgs: 1 },
  { name: 'ROUND', category: 'Math', signature: 'ROUND(number, [digits])', description: 'Rounds a number to a specified number of decimal places.', example: '=ROUND(3.14159, 2)', minArgs: 1, maxArgs: 2 },
  { name: 'FLOOR', category: 'Math', signature: 'FLOOR(number, [significance])', description: 'Rounds a number down toward zero to the nearest multiple of significance.', example: '=FLOOR(47.8, 5)', minArgs: 1, maxArgs: 2 },
  { name: 'CEIL', category: 'Math', signature: 'CEIL(number, [significance])', description: 'Rounds a number up to the nearest integer or multiple of significance.', example: '=CEIL(42.1, 1)', minArgs: 1, maxArgs: 2 },
  { name: 'SQRT', category: 'Math', signature: 'SQRT(number)', description: 'Returns the positive square root of a number.', example: '=SQRT(144)', minArgs: 1, maxArgs: 1 },
  { name: 'POWER', category: 'Math', signature: 'POWER(base, exponent)', description: 'Returns the result of a number raised to a power.', example: '=POWER(2, 10)', minArgs: 2, maxArgs: 2 },
  { name: 'MOD', category: 'Math', signature: 'MOD(dividend, divisor)', description: 'Returns the remainder after division.', example: '=MOD(17, 5)', minArgs: 2, maxArgs: 2 },
  { name: 'PRODUCT', category: 'Math', signature: 'PRODUCT(value1, [value2, ...])', description: 'Multiplies all numeric values given as arguments.', example: '=PRODUCT(B2:B5)', minArgs: 1, maxArgs: 99 },

  // Logic (7)
  { name: 'IF', category: 'Logic', signature: 'IF(condition, value_if_true, [value_if_false])', description: 'Evaluates a logical condition and branches lazily.', example: '=IF(C2>1000, "Exceeds", "On Track")', minArgs: 2, maxArgs: 3 },
  { name: 'IFS', category: 'Logic', signature: 'IFS(cond1, val1, [cond2, val2, ...])', description: 'Evaluates multiple conditions in sequence and returns the first true match.', example: '=IFS(B2>90, "A", B2>80, "B", TRUE, "C")', minArgs: 2, maxArgs: 99 },
  { name: 'AND', category: 'Logic', signature: 'AND(logical1, [logical2, ...])', description: 'Returns TRUE if all arguments evaluate to true.', example: '=AND(B2>0, C2<100)', minArgs: 1, maxArgs: 99 },
  { name: 'OR', category: 'Logic', signature: 'OR(logical1, [logical2, ...])', description: 'Returns TRUE if at least one argument evaluates to true.', example: '=OR(B2>100, C2>100)', minArgs: 1, maxArgs: 99 },
  { name: 'NOT', category: 'Logic', signature: 'NOT(logical)', description: 'Reverses the boolean value of its argument.', example: '=NOT(B2=0)', minArgs: 1, maxArgs: 1 },
  { name: 'XOR', category: 'Logic', signature: 'XOR(logical1, [logical2, ...])', description: 'Returns TRUE if an odd number of arguments evaluate to TRUE.', example: '=XOR(B2>10, C2>10)', minArgs: 1, maxArgs: 99 },
  { name: 'IFERROR', category: 'Logic', signature: 'IFERROR(value, fallback_value)', description: 'Returns fallback_value if the first expression produces any error.', example: '=IFERROR(B2/C2, 0)', minArgs: 2, maxArgs: 2 },

  // Lookup & Reference (6)
  { name: 'VLOOKUP', category: 'Lookup', signature: 'VLOOKUP(search_key, range, col_index, [is_sorted])', description: 'Vertical lookup down the first column of a range and returns a cell in the same row.', example: '=VLOOKUP("Enterprise", A2:D6, 3, FALSE)', minArgs: 3, maxArgs: 4 },
  { name: 'HLOOKUP', category: 'Lookup', signature: 'HLOOKUP(search_key, range, row_index, [is_sorted])', description: 'Horizontal lookup across the top row of a range and returns a value from row_index.', example: '=HLOOKUP("Q2", B1:E5, 2, FALSE)', minArgs: 3, maxArgs: 4 },
  { name: 'INDEX', category: 'Lookup', signature: 'INDEX(range, row_num, [col_num])', description: 'Returns the cell value at a given 1-based row and column offset inside a range.', example: '=INDEX(B2:E6, 2, 3)', minArgs: 2, maxArgs: 3 },
  { name: 'MATCH', category: 'Lookup', signature: 'MATCH(search_key, range, [match_type])', description: 'Returns the 1-based relative position of an item in a 1D range.', example: '=MATCH("Pro", A2:A6, 0)', minArgs: 2, maxArgs: 3 },
  { name: 'CHOOSE', category: 'Lookup', signature: 'CHOOSE(index_num, val1, [val2, ...])', description: 'Returns a value from a list of arguments based on a 1-based index.', example: '=CHOOSE(2, "Low", "Medium", "High")', minArgs: 2, maxArgs: 99 },
  { name: 'COUNTBLANK', category: 'Lookup', signature: 'COUNTBLANK(range)', description: 'Counts empty cells inside a range.', example: '=COUNTBLANK(B2:B10)', minArgs: 1, maxArgs: 99 },

  // Statistical (7)
  { name: 'COUNT', category: 'Statistical', signature: 'COUNT(value1, [value2, ...])', description: 'Counts how many numeric values are in the argument list or range.', example: '=COUNT(B2:B10)', minArgs: 1, maxArgs: 99 },
  { name: 'COUNTA', category: 'Statistical', signature: 'COUNTA(value1, [value2, ...])', description: 'Counts non-empty cells across values or ranges.', example: '=COUNTA(A2:A10)', minArgs: 1, maxArgs: 99 },
  { name: 'COUNTIF', category: 'Statistical', signature: 'COUNTIF(range, criterion)', description: 'Counts cells in a range matching a condition (e.g. ">100", "=Enterprise").', example: '=COUNTIF(B2:B6, ">150")', minArgs: 2, maxArgs: 2 },
  { name: 'SUMIF', category: 'Statistical', signature: 'SUMIF(range, criterion, [sum_range])', description: 'Sums cells that satisfy a given criterion.', example: '=SUMIF(B2:B6, ">100", C2:C6)', minArgs: 2, maxArgs: 3 },
  { name: 'AVERAGEIF', category: 'Statistical', signature: 'AVERAGEIF(range, criterion, [avg_range])', description: 'Averages cells that satisfy a given criterion.', example: '=AVERAGEIF(B2:B6, ">100")', minArgs: 2, maxArgs: 3 },
  { name: 'MEDIAN', category: 'Statistical', signature: 'MEDIAN(value1, [value2, ...])', description: 'Returns the median (middle value) of numeric arguments.', example: '=MEDIAN(B2:E2)', minArgs: 1, maxArgs: 99 },
  { name: 'STDEV', category: 'Statistical', signature: 'STDEV(value1, [value2, ...])', description: 'Calculates sample standard deviation of numeric data.', example: '=STDEV(B2:E2)', minArgs: 1, maxArgs: 99 },

  // Text (5)
  { name: 'CONCAT', category: 'Text', signature: 'CONCAT(text1, [text2, ...])', description: 'Joins multiple text strings or cell values into one string.', example: '=CONCAT(A2, " - ", B2)', minArgs: 1, maxArgs: 99 },
  { name: 'LEN', category: 'Text', signature: 'LEN(text)', description: 'Returns the character length of a string.', example: '=LEN(A2)', minArgs: 1, maxArgs: 1 },
  { name: 'UPPER', category: 'Text', signature: 'UPPER(text)', description: 'Converts a string to all uppercase letters.', example: '=UPPER(A2)', minArgs: 1, maxArgs: 1 },
  { name: 'LOWER', category: 'Text', signature: 'LOWER(text)', description: 'Converts a string to all lowercase letters.', example: '=LOWER(A2)', minArgs: 1, maxArgs: 1 },
  { name: 'TRIM', category: 'Text', signature: 'TRIM(text)', description: 'Removes leading, trailing, and repeated spaces from text.', example: '=TRIM(A2)', minArgs: 1, maxArgs: 1 },

  // Visual & Finance (3)
  { name: 'SPARKLINE', category: 'Visual & Finance', signature: 'SPARKLINE(range)', description: 'Novel Feature: Renders an inline SVG trend sparkline inside the cell and evaluates to the period growth %.', example: '=SPARKLINE(B2:E2)', minArgs: 1, maxArgs: 1 },
  { name: 'BAR', category: 'Visual & Finance', signature: 'BAR(value, max_value)', description: 'Novel Feature: Renders an inline proportional progress bar inside the cell and evaluates to the percentage ratio.', example: '=BAR(F2, 2000)', minArgs: 2, maxArgs: 2 },
  { name: 'NPV', category: 'Visual & Finance', signature: 'NPV(discount_rate, cashflow_range)', description: 'Calculates the Net Present Value of periodic cash flows at a discount rate.', example: '=NPV(0.08, B2:E2)', minArgs: 2, maxArgs: 99 },
];

const KNOWN_FUNCTION_NAMES = new Set(FUNCTION_CATALOG.map((f) => f.name));
const FUNCTION_MAP = new Map(FUNCTION_CATALOG.map((f) => [f.name, f]));

// Levenshtein distance for typo correction in function names (e.g. VLLOKUP -> VLOOKUP)
function levenshteinDistance(a: string, b: string): number {
  const dp: number[][] = Array.from({ length: a.length + 1 }, () => Array(b.length + 1).fill(0));
  for (let i = 0; i <= a.length; i++) dp[i][0] = i;
  for (let j = 0; j <= b.length; j++) dp[0][j] = j;
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost);
    }
  }
  return dp[a.length][b.length];
}

function findClosestFunctionName(input: string): string | null {
  const upper = input.toUpperCase();
  let best = '';
  let bestDist = Infinity;
  for (const fn of KNOWN_FUNCTION_NAMES) {
    const d = levenshteinDistance(upper, fn);
    if (d < bestDist) {
      bestDist = d;
      best = fn;
    }
  }
  return bestDist <= 3 ? best : null;
}


export { KNOWN_FUNCTION_NAMES, FUNCTION_MAP, levenshteinDistance, findClosestFunctionName };

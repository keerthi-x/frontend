import { ASTNode, CellValue, CaretDiagnostic, SparklineMeta } from './types';
import { expandRange, parseCellId, colIndexToLabel } from './coordinates';

// ============================================================================
// 6. DEPENDENCY EXTRACTION & INCREMENTAL TOPOLOGICAL DAG ENGINE
// ============================================================================

export function extractDependenciesFromAST(node: ASTNode | null): string[] {
  if (!node) return [];
  const deps = new Set<string>();

  function walk(n: ASTNode) {
    switch (n.kind) {
      case 'CellRef':
        deps.add(n.cellId);
        break;
      case 'RangeRef': {
        const { cells } = expandRange(n.startCell, n.endCell);
        for (const c of cells) deps.add(c);
        break;
      }
      case 'UnaryExpr':
        walk(n.operand);
        break;
      case 'BinaryExpr':
        walk(n.left);
        walk(n.right);
        break;
      case 'FunctionCall':
        for (const arg of n.args) walk(arg);
        break;
      default:
        break;
    }
  }

  walk(node);
  return Array.from(deps);
}

// Evaluates a criterion string like ">100", "<=50", "<>0", "Enterprise", "=Pro"
function matchesCriterion(val: CellValue, criterionRaw: CellValue): boolean {
  const crit = String(criterionRaw ?? '').trim();
  const match = /^(<=|>=|<>|!=|=|<|>)(.*)$/.exec(crit);
  const op = match ? match[1] : '=';
  const rhsRaw = match ? match[2].trim() : crit;
  const rhsNum = Number(rhsRaw);
  const valNum = typeof val === 'number' ? val : Number(val);
  const bothNumeric = rhsRaw !== '' && !Number.isNaN(rhsNum) && val !== null && val !== '' && !Number.isNaN(valNum);

  if (bothNumeric) {
    if (op === '>') return valNum > rhsNum;
    if (op === '>=') return valNum >= rhsNum;
    if (op === '<') return valNum < rhsNum;
    if (op === '<=') return valNum <= rhsNum;
    if (op === '<>' || op === '!=') return valNum !== rhsNum;
    return valNum === rhsNum;
  }

  const lhsStr = String(val ?? '').toLowerCase();
  const rhsStr = rhsRaw.replace(/^"|"$/g, '').toLowerCase();
  if (op === '<>' || op === '!=') return lhsStr !== rhsStr;
  return lhsStr === rhsStr;
}

function toNumber(v: CellValue): number {
  if (typeof v === 'number') return v;
  if (typeof v === 'boolean') return v ? 1 : 0;
  if (v === null || v === '') return 0;
  const parsed = Number(v);
  return Number.isNaN(parsed) ? NaN : parsed;
}

function toBoolean(v: CellValue): boolean {
  if (typeof v === 'boolean') return v;
  if (typeof v === 'number') return v !== 0;
  if (typeof v === 'string') return v.toUpperCase() === 'TRUE';
  return false;
}

function isErrorCode(v: CellValue): boolean {
  return typeof v === 'string' && v.startsWith('#') && (v.endsWith('!') || v.endsWith('?') || v === '#N/A');
}

export function evaluateAST(
  node: ASTNode,
  formula: string,
  getCellValue: (cellId: string) => CellValue
): { value: CellValue; runtimeError: CaretDiagnostic | null; sparkline?: SparklineMeta } {
  let runtimeError: CaretDiagnostic | null = null;
  let sparklineMeta: SparklineMeta | undefined;

  function evalFlatValues(arg: ASTNode): CellValue[] {
    if (arg.kind === 'RangeRef') {
      const { cells } = expandRange(arg.startCell, arg.endCell);
      return cells.map((id) => getCellValue(id));
    }
    return [evalNode(arg)];
  }

  function evalNumericValues(args: ASTNode[]): { nums: number[]; err: CellValue | null } {
    const nums: number[] = [];
    for (const arg of args) {
      if (arg.kind === 'RangeRef') {
        const { cells } = expandRange(arg.startCell, arg.endCell);
        for (const id of cells) {
          const v = getCellValue(id);
          if (isErrorCode(v)) return { nums: [], err: v };
          if (typeof v === 'number' && !Number.isNaN(v)) nums.push(v);
        }
      } else {
        const v = evalNode(arg);
        if (isErrorCode(v)) return { nums: [], err: v };
        const n = toNumber(v);
        if (!Number.isNaN(n)) nums.push(n);
      }
    }
    return { nums, err: null };
  }

  function evalNode(n: ASTNode): CellValue {
    switch (n.kind) {
      case 'NumberLiteral':
        return n.value;
      case 'StringLiteral':
        return n.value;
      case 'BooleanLiteral':
        return n.value;
      case 'CellRef': {
        const v = getCellValue(n.cellId);
        return v === null ? 0 : v;
      }
      case 'RangeRef': {
        // Bare range outside aggregate function evaluates to top-left cell
        return getCellValue(n.startCell);
      }
      case 'ErrorNode':
        return '#SYNTAX!';
      case 'UnaryExpr': {
        const val = evalNode(n.operand);
        if (isErrorCode(val)) return val;
        const num = toNumber(val);
        if (Number.isNaN(num)) {
          if (!runtimeError) {
            runtimeError = {
              code: '#VALUE!',
              message: `Unary operator '${n.op}' expects a numeric value, got "${val}".`,
              formula,
              caretStart: n.span.start,
              caretLength: n.span.end - n.span.start,
              suggestion: 'Ensure the referenced cell contains a number.',
            };
          }
          return '#VALUE!';
        }
        return n.op === '-' ? -num : num;
      }
      case 'BinaryExpr': {
        const lv = evalNode(n.left);
        if (isErrorCode(lv)) return lv;
        const rv = evalNode(n.right);
        if (isErrorCode(rv)) return rv;

        if (n.op === '&') {
          return `${lv ?? ''}${rv ?? ''}`;
        }

        if (['=', '<>', '<', '<=', '>', '>='].includes(n.op)) {
          const lNum = toNumber(lv);
          const rNum = toNumber(rv);
          const bothNum = !Number.isNaN(lNum) && !Number.isNaN(rNum) && typeof lv !== 'string' && typeof rv !== 'string';
          const a = bothNum ? lNum : String(lv ?? '').toLowerCase();
          const b = bothNum ? rNum : String(rv ?? '').toLowerCase();
          if (n.op === '=') return a === b;
          if (n.op === '<>') return a !== b;
          if (n.op === '<') return a < b;
          if (n.op === '<=') return a <= b;
          if (n.op === '>') return a > b;
          if (n.op === '>=') return a >= b;
        }

        const lNum = toNumber(lv);
        const rNum = toNumber(rv);
        if (Number.isNaN(lNum) || Number.isNaN(rNum)) {
          if (!runtimeError) {
            runtimeError = {
              code: '#VALUE!',
              message: `Arithmetic operator '${n.op}' cannot combine non-numeric values ("${lv}" and "${rv}").`,
              formula,
              caretStart: n.span.start,
              caretLength: n.span.end - n.span.start,
              suggestion: 'Use CONCAT(...) or "&" for text, or convert operands to numbers.',
            };
          }
          return '#VALUE!';
        }

        if (n.op === '+') return lNum + rNum;
        if (n.op === '-') return lNum - rNum;
        if (n.op === '*') return lNum * rNum;
        if (n.op === '^') return Math.pow(lNum, rNum);
        if (n.op === '/' || n.op === '%') {
          if (rNum === 0) {
            if (!runtimeError) {
              runtimeError = {
                code: '#DIV/0!',
                message: 'Division by zero (divisor evaluated to 0).',
                formula,
                caretStart: n.right.span.start,
                caretLength: Math.max(1, n.right.span.end - n.right.span.start),
                suggestion: `Wrap in =IFERROR(${formula.slice(1)}, 0) to guard against zero divisors.`,
                fixedFormula: `=IFERROR(${formula.slice(1)}, 0)`,
              };
            }
            return '#DIV/0!';
          }
          return n.op === '/' ? lNum / rNum : lNum % rNum;
        }
        return '#VALUE!';
      }

      case 'FunctionCall': {
        const fn = n.name;

        // Lazy-evaluated conditional functions first
        if (fn === 'IF') {
          const cond = evalNode(n.args[0]);
          if (isErrorCode(cond)) return cond;
          if (toBoolean(cond)) {
            return evalNode(n.args[1]);
          }
          return n.args[2] ? evalNode(n.args[2]) : false;
        }

        if (fn === 'IFS') {
          for (let i = 0; i + 1 < n.args.length; i += 2) {
            const c = evalNode(n.args[i]);
            if (isErrorCode(c)) return c;
            if (toBoolean(c)) return evalNode(n.args[i + 1]);
          }
          return '#N/A';
        }

        if (fn === 'IFERROR') {
          const prevRuntimeErr = runtimeError;
          const primary = evalNode(n.args[0]);
          if (isErrorCode(primary)) {
            runtimeError = prevRuntimeErr; // Clear inner error since IFERROR caught it
            return evalNode(n.args[1]);
          }
          return primary;
        }

        // Aggregate Math & Stats
        if (['SUM', 'AVERAGE', 'MIN', 'MAX', 'PRODUCT', 'MEDIAN', 'STDEV'].includes(fn)) {
          const { nums, err } = evalNumericValues(n.args);
          if (err) return err;
          if (fn === 'SUM') return nums.reduce((a, b) => a + b, 0);
          if (fn === 'PRODUCT') return nums.length ? nums.reduce((a, b) => a * b, 1) : 0;
          if (nums.length === 0) return fn === 'AVERAGE' ? '#DIV/0!' : 0;
          if (fn === 'AVERAGE') return nums.reduce((a, b) => a + b, 0) / nums.length;
          if (fn === 'MIN') return Math.min(...nums);
          if (fn === 'MAX') return Math.max(...nums);
          if (fn === 'MEDIAN') {
            const sorted = [...nums].sort((a, b) => a - b);
            const mid = Math.floor(sorted.length / 2);
            return sorted.length % 2 !== 0 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
          }
          if (fn === 'STDEV') {
            if (nums.length < 2) return 0;
            const mean = nums.reduce((a, b) => a + b, 0) / nums.length;
            const variance = nums.reduce((acc, v) => acc + (v - mean) ** 2, 0) / (nums.length - 1);
            return Math.sqrt(variance);
          }
        }

        // Single/Dual Math
        if (fn === 'ABS') return Math.abs(toNumber(evalNode(n.args[0])));
        if (fn === 'SQRT') {
          const val = toNumber(evalNode(n.args[0]));
          if (val < 0) return '#VALUE!';
          return Math.sqrt(val);
        }
        if (fn === 'ROUND') {
          const val = toNumber(evalNode(n.args[0]));
          const digits = n.args[1] ? Math.round(toNumber(evalNode(n.args[1]))) : 0;
          const factor = Math.pow(10, digits);
          return Math.round(val * factor) / factor;
        }
        if (fn === 'FLOOR') {
          const val = toNumber(evalNode(n.args[0]));
          const sig = n.args[1] ? toNumber(evalNode(n.args[1])) : 1;
          return sig === 0 ? 0 : Math.floor(val / sig) * sig;
        }
        if (fn === 'CEIL') {
          const val = toNumber(evalNode(n.args[0]));
          const sig = n.args[1] ? toNumber(evalNode(n.args[1])) : 1;
          return sig === 0 ? 0 : Math.ceil(val / sig) * sig;
        }
        if (fn === 'POWER') {
          return Math.pow(toNumber(evalNode(n.args[0])), toNumber(evalNode(n.args[1])));
        }
        if (fn === 'MOD') {
          const d = toNumber(evalNode(n.args[1]));
          if (d === 0) return '#DIV/0!';
          return toNumber(evalNode(n.args[0])) % d;
        }

        // Boolean Logic
        if (fn === 'AND' || fn === 'OR' || fn === 'XOR') {
          const flat = n.args.flatMap(evalFlatValues);
          const bools = flat.map(toBoolean);
          if (fn === 'AND') return bools.every(Boolean);
          if (fn === 'OR') return bools.some(Boolean);
          return bools.filter(Boolean).length % 2 === 1;
        }
        if (fn === 'NOT') {
          return !toBoolean(evalNode(n.args[0]));
        }

        // Counting
        if (fn === 'COUNT' || fn === 'COUNTA' || fn === 'COUNTBLANK') {
          const flat = n.args.flatMap(evalFlatValues);
          if (fn === 'COUNT') return flat.filter((v) => typeof v === 'number' && !Number.isNaN(v)).length;
          if (fn === 'COUNTA') return flat.filter((v) => v !== null && v !== '').length;
          return flat.filter((v) => v === null || v === '').length;
        }

        // Conditional Range Functions: COUNTIF, SUMIF, AVERAGEIF
        if (fn === 'COUNTIF' || fn === 'SUMIF' || fn === 'AVERAGEIF') {
          const rangeValues = evalFlatValues(n.args[0]);
          const criterion = evalNode(n.args[1]);
          const targetValues = n.args[2] ? evalFlatValues(n.args[2]) : rangeValues;

          let count = 0;
          let sum = 0;
          for (let i = 0; i < rangeValues.length; i++) {
            if (matchesCriterion(rangeValues[i], criterion)) {
              count++;
              const tv = toNumber(targetValues[i] ?? 0);
              if (!Number.isNaN(tv)) sum += tv;
            }
          }
          if (fn === 'COUNTIF') return count;
          if (fn === 'SUMIF') return sum;
          return count === 0 ? '#DIV/0!' : sum / count;
        }

        // Lookup Functions: VLOOKUP, HLOOKUP, INDEX, MATCH, CHOOSE
        if (fn === 'VLOOKUP') {
          const searchKey = evalNode(n.args[0]);
          const rangeNode = n.args[1];
          const colIdx = Math.round(toNumber(evalNode(n.args[2])));
          const isSorted = n.args[3] ? toBoolean(evalNode(n.args[3])) : false;

          if (rangeNode.kind !== 'RangeRef') return '#REF!';
          const start = parseCellId(rangeNode.startCell);
          const end = parseCellId(rangeNode.endCell);
          if (!start || !end) return '#REF!';

          const minCol = Math.min(start.col, end.col);
          const maxCol = Math.max(start.col, end.col);
          const minRow = Math.min(start.row, end.row);
          const maxRow = Math.max(start.row, end.row);
          const totalCols = maxCol - minCol + 1;

          if (colIdx < 1 || colIdx > totalCols) {
            if (!runtimeError) {
              runtimeError = {
                code: '#REF!',
                message: `VLOOKUP column index ${colIdx} is out of bounds for range ${rangeNode.raw} (which has ${totalCols} column${totalCols === 1 ? '' : 's'}).`,
                formula,
                caretStart: n.args[2].span.start,
                caretLength: n.args[2].span.end - n.args[2].span.start,
                suggestion: `Choose a column index between 1 and ${totalCols}.`,
                fixedFormula:
                  formula.slice(0, n.args[2].span.start) + String(totalCols) + formula.slice(n.args[2].span.end),
              };
            }
            return '#REF!';
          }

          let matchedRow = -1;
          for (let r = minRow; r <= maxRow; r++) {
            const cellVal = getCellValue(`${colIndexToLabel(minCol)}${r + 1}`);
            const exactMatch =
              String(cellVal ?? '').toLowerCase() === String(searchKey ?? '').toLowerCase() ||
              (typeof cellVal === 'number' && typeof searchKey === 'number' && cellVal === searchKey);
            if (exactMatch) {
              matchedRow = r;
              break;
            }
            if (isSorted && typeof cellVal === 'number' && typeof searchKey === 'number' && cellVal <= searchKey) {
              matchedRow = r;
            }
          }

          if (matchedRow === -1) {
            if (!runtimeError) {
              runtimeError = {
                code: '#N/A',
                message: `VLOOKUP could not find "${searchKey}" in the first column of ${rangeNode.raw}.`,
                formula,
                caretStart: n.args[0].span.start,
                caretLength: n.args[0].span.end - n.args[0].span.start,
                suggestion: 'Check that the lookup key exists in the leftmost column of the lookup range.',
              };
            }
            return '#N/A';
          }
          const targetCol = minCol + colIdx - 1;
          return getCellValue(`${colIndexToLabel(targetCol)}${matchedRow + 1}`);
        }

        if (fn === 'HLOOKUP') {
          const searchKey = evalNode(n.args[0]);
          const rangeNode = n.args[1];
          const rowIdx = Math.round(toNumber(evalNode(n.args[2])));
          if (rangeNode.kind !== 'RangeRef') return '#REF!';
          const start = parseCellId(rangeNode.startCell);
          const end = parseCellId(rangeNode.endCell);
          if (!start || !end) return '#REF!';

          const minCol = Math.min(start.col, end.col);
          const maxCol = Math.max(start.col, end.col);
          const minRow = Math.min(start.row, end.row);
          const maxRow = Math.max(start.row, end.row);
          const totalRows = maxRow - minRow + 1;

          if (rowIdx < 1 || rowIdx > totalRows) return '#REF!';
          for (let c = minCol; c <= maxCol; c++) {
            const cellVal = getCellValue(`${colIndexToLabel(c)}${minRow + 1}`);
            if (String(cellVal ?? '').toLowerCase() === String(searchKey ?? '').toLowerCase()) {
              return getCellValue(`${colIndexToLabel(c)}${minRow + rowIdx}`);
            }
          }
          return '#N/A';
        }

        if (fn === 'INDEX') {
          const rangeNode = n.args[0];
          const rowNum = Math.round(toNumber(evalNode(n.args[1])));
          const colNum = n.args[2] ? Math.round(toNumber(evalNode(n.args[2]))) : 1;
          if (rangeNode.kind !== 'RangeRef') return '#REF!';
          const start = parseCellId(rangeNode.startCell);
          const end = parseCellId(rangeNode.endCell);
          if (!start || !end) return '#REF!';
          const minCol = Math.min(start.col, end.col);
          const maxCol = Math.max(start.col, end.col);
          const minRow = Math.min(start.row, end.row);
          const maxRow = Math.max(start.row, end.row);

          const targetRow = minRow + rowNum - 1;
          const targetCol = minCol + colNum - 1;
          if (targetRow < minRow || targetRow > maxRow || targetCol < minCol || targetCol > maxCol) return '#REF!';
          return getCellValue(`${colIndexToLabel(targetCol)}${targetRow + 1}`);
        }

        if (fn === 'MATCH') {
          const searchKey = evalNode(n.args[0]);
          const vals = evalFlatValues(n.args[1]);
          for (let i = 0; i < vals.length; i++) {
            if (String(vals[i] ?? '').toLowerCase() === String(searchKey ?? '').toLowerCase()) {
              return i + 1;
            }
          }
          return '#N/A';
        }

        if (fn === 'CHOOSE') {
          const idx = Math.round(toNumber(evalNode(n.args[0])));
          if (idx < 1 || idx >= n.args.length) return '#VALUE!';
          return evalNode(n.args[idx]);
        }

        // Text Functions
        if (fn === 'CONCAT') {
          const flat = n.args.flatMap(evalFlatValues);
          return flat.map((v) => String(v ?? '')).join('');
        }
        if (fn === 'LEN') return String(evalNode(n.args[0]) ?? '').length;
        if (fn === 'UPPER') return String(evalNode(n.args[0]) ?? '').toUpperCase();
        if (fn === 'LOWER') return String(evalNode(n.args[0]) ?? '').toLowerCase();
        if (fn === 'TRIM') return String(evalNode(n.args[0]) ?? '').trim().replace(/\s+/g, ' ');

        // Novel Visual & Finance Functions
        if (fn === 'SPARKLINE') {
          const { nums } = evalNumericValues(n.args);
          if (nums.length >= 2) {
            sparklineMeta = { kind: 'sparkline', values: nums };
            const first = nums[0] || 1;
            const last = nums[nums.length - 1];
            const pct = ((last - first) / Math.abs(first)) * 100;
            return `${pct >= 0 ? '+' : ''}${pct.toFixed(1)}%`;
          }
          return 0;
        }

        if (fn === 'BAR') {
          const v = toNumber(evalNode(n.args[0]));
          const maxV = Math.max(1, toNumber(evalNode(n.args[1])));
          sparklineMeta = { kind: 'bar', values: [v], max: maxV };
          return Math.round((v / maxV) * 100);
        }

        if (fn === 'NPV') {
          const rate = toNumber(evalNode(n.args[0]));
          const { nums: cashflows } = evalNumericValues(n.args.slice(1));
          return cashflows.reduce((acc, cf, idx) => acc + cf / Math.pow(1 + rate, idx + 1), 0);
        }

        return '#NAME?';
      }
    }
  }

  const value = evalNode(node);
  return { value, runtimeError, sparkline: sparklineMeta };
}


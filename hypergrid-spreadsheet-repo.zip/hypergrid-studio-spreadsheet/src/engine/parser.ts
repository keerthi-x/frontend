import { ASTNode, Token, CaretDiagnostic } from './types';
import { normalizeCellId, expandRange, parseCellId } from './coordinates';
import { KNOWN_FUNCTION_NAMES, FUNCTION_MAP, findClosestFunctionName } from './functions';
import { tokenizeFormula } from './lexer';

// ============================================================================
// 5. PRATT / RECURSIVE-DESCENT AST PARSER WITH CARET DIAGNOSTICS
// ============================================================================

export function parseFormula(formula: string): {
  ast: ASTNode | null;
  tokens: Token[];
  error: CaretDiagnostic | null;
} {
  const { tokens, lexerError } = tokenizeFormula(formula);
  if (lexerError) {
    return { ast: null, tokens, error: lexerError };
  }

  // Handle empty formula "="
  if (tokens.length === 1 && tokens[0].type === 'EOF') {
    return {
      ast: null,
      tokens,
      error: {
        code: '#SYNTAX!',
        message: 'Incomplete formula after "=" sign.',
        formula,
        caretStart: formula.length,
        caretLength: 1,
        suggestion: 'Enter a cell reference, number, or function after "=", such as =SUM(A1:A5).',
        fixedFormula: '=0',
      },
    };
  }

  // Pre-pass: check parenthesis balance for crisp caret reporting
  let openParens = 0;
  for (const tok of tokens) {
    if (tok.type === 'LPAREN') openParens++;
    if (tok.type === 'RPAREN') {
      if (openParens === 0) {
        const fixed = formula.slice(0, tok.span.start) + formula.slice(tok.span.end);
        return {
          ast: null,
          tokens,
          error: {
            code: '#SYNTAX!',
            message: 'Unexpected closing parenthesis with no matching opening parenthesis.',
            formula,
            caretStart: tok.span.start,
            caretLength: 1,
            suggestion: "Remove the extra ')' at this position.",
            fixedFormula: fixed,
          },
        };
      }
      openParens--;
    }
  }

  if (openParens > 0) {
    const missingStr = ')'.repeat(openParens);
    return {
      ast: null,
      tokens,
      error: {
        code: '#SYNTAX!',
        message: openParens === 1 ? 'Missing closing parenthesis.' : `Missing ${openParens} closing parentheses.`,
        formula,
        caretStart: formula.length,
        caretLength: 1,
        suggestion: `Add '${missingStr}' at the end of the formula.`,
        fixedFormula: `${formula}${missingStr}`,
      },
    };
  }

  let pos = 0;
  let diagnosticError: CaretDiagnostic | null = null;

  const peek = (): Token => tokens[pos] || tokens[tokens.length - 1];
  const consume = (): Token => tokens[pos++];

  function parseExpression(): ASTNode {
    return parseComparison();
  }

  function parseComparison(): ASTNode {
    let left = parseConcat();
    while (peek().type === 'COMPARE') {
      const opTok = consume();
      const right = parseConcat();
      left = {
        kind: 'BinaryExpr',
        op: opTok.value,
        left,
        right,
        span: { start: left.span.start, end: right.span.end },
      };
    }
    return left;
  }

  function parseConcat(): ASTNode {
    let left = parseAdditive();
    while (peek().type === 'OP' && peek().value === '&') {
      const opTok = consume();
      const right = parseAdditive();
      left = {
        kind: 'BinaryExpr',
        op: opTok.value,
        left,
        right,
        span: { start: left.span.start, end: right.span.end },
      };
    }
    return left;
  }

  function parseAdditive(): ASTNode {
    let left = parseMultiplicative();
    while (peek().type === 'OP' && (peek().value === '+' || peek().value === '-')) {
      const opTok = consume();
      const right = parseMultiplicative();
      left = {
        kind: 'BinaryExpr',
        op: opTok.value,
        left,
        right,
        span: { start: left.span.start, end: right.span.end },
      };
    }
    return left;
  }

  function parseMultiplicative(): ASTNode {
    let left = parseExponent();
    while (peek().type === 'OP' && (peek().value === '*' || peek().value === '/' || peek().value === '%')) {
      const opTok = consume();
      if (opTok.value === '%' && (peek().type === 'EOF' || peek().type === 'RPAREN' || peek().type === 'COMMA' || peek().type === 'OP' || peek().type === 'COMPARE')) {
        // Postfix percentage e.g. 50%
        left = {
          kind: 'BinaryExpr',
          op: '/',
          left,
          right: { kind: 'NumberLiteral', value: 100, span: opTok.span },
          span: { start: left.span.start, end: opTok.span.end },
        };
        continue;
      }
      const right = parseExponent();
      left = {
        kind: 'BinaryExpr',
        op: opTok.value,
        left,
        right,
        span: { start: left.span.start, end: right.span.end },
      };
    }
    return left;
  }

  function parseExponent(): ASTNode {
    const left = parseUnary();
    if (peek().type === 'OP' && peek().value === '^') {
      const opTok = consume();
      const right = parseExponent(); // Right-associative
      return {
        kind: 'BinaryExpr',
        op: opTok.value,
        left,
        right,
        span: { start: left.span.start, end: right.span.end },
      };
    }
    return left;
  }

  function parseUnary(): ASTNode {
    if (peek().type === 'OP' && (peek().value === '+' || peek().value === '-')) {
      const opTok = consume();
      const operand = parseUnary();
      return {
        kind: 'UnaryExpr',
        op: opTok.value,
        operand,
        span: { start: opTok.span.start, end: operand.span.end },
      };
    }
    return parsePrimary();
  }

  function parsePrimary(): ASTNode {
    const tok = peek();

    if (tok.type === 'NUMBER') {
      consume();
      return { kind: 'NumberLiteral', value: parseFloat(tok.value), span: tok.span };
    }

    if (tok.type === 'STRING') {
      consume();
      return { kind: 'StringLiteral', value: tok.value, span: tok.span };
    }

    if (tok.type === 'BOOLEAN') {
      consume();
      return { kind: 'BooleanLiteral', value: tok.value === 'TRUE', span: tok.span };
    }

    if (tok.type === 'CELL_REF') {
      const startTok = consume();
      if (peek().type === 'COLON') {
        const colonTok = consume();
        const endTok = peek();
        if (endTok.type !== 'CELL_REF') {
          if (!diagnosticError) {
            diagnosticError = {
              code: '#SYNTAX!',
              message: `Expected a valid cell reference after ':' in range (starting at ${startTok.value}).`,
              formula,
              caretStart: colonTok.span.end,
              caretLength: Math.max(1, endTok.span.end - endTok.span.start),
              suggestion: `Specify an ending cell after ':', e.g. '${startTok.value}:${startTok.value}'.`,
              fixedFormula: `${formula.slice(0, colonTok.span.end)}${startTok.value}${formula.slice(colonTok.span.end)}`,
            };
          }
          return { kind: 'ErrorNode', message: 'Invalid range end', span: colonTok.span };
        }
        consume();
        const startNorm = normalizeCellId(startTok.value);
        const endNorm = normalizeCellId(endTok.value);
        const { inverted } = expandRange(startNorm, endNorm, 10);
        if (inverted && !diagnosticError) {
          const fixedRange = `${endTok.value}:${startTok.value}`;
          diagnosticError = {
            code: '#REF!',
            message: `Inverted range '${startTok.value}:${endTok.value}' (top-left cell must precede bottom-right cell).`,
            formula,
            caretStart: startTok.span.start,
            caretLength: endTok.span.end - startTok.span.start,
            suggestion: `Swap range bounds to '${fixedRange}'.`,
            fixedFormula: formula.slice(0, startTok.span.start) + fixedRange + formula.slice(endTok.span.end),
          };
        }
        return {
          kind: 'RangeRef',
          startCell: startNorm,
          endCell: endNorm,
          raw: `${startTok.value}:${endTok.value}`,
          span: { start: startTok.span.start, end: endTok.span.end },
        };
      }

      const parsed = parseCellId(startTok.value);
      return {
        kind: 'CellRef',
        cellId: normalizeCellId(startTok.value),
        raw: startTok.value,
        absCol: parsed?.absCol ?? false,
        absRow: parsed?.absRow ?? false,
        span: startTok.span,
      };
    }

    if (tok.type === 'FUNC') {
      const fnTok = consume();
      const fnName = fnTok.value.toUpperCase();

      // Check if function name exists; if not, compute Levenshtein suggestion
      if (!KNOWN_FUNCTION_NAMES.has(fnName) && !diagnosticError) {
        const closest = findClosestFunctionName(fnName);
        const suggestion = closest
          ? `Replace '${fnName}' with '${closest}'.`
          : `Use a supported function such as SUM, AVERAGE, IF, or VLOOKUP.`;
        const fixedFormula = closest
          ? formula.slice(0, fnTok.span.start) + closest + formula.slice(fnTok.span.end)
          : undefined;
        diagnosticError = {
          code: '#NAME?',
          message: closest
            ? `Unknown function '${fnName}'. Did you mean '${closest}'?`
            : `Unknown function '${fnName}'.`,
          formula,
          caretStart: fnTok.span.start,
          caretLength: fnTok.span.end - fnTok.span.start,
          suggestion,
          fixedFormula,
        };
      }

      // Expect '('
      if (peek().type === 'LPAREN') {
        consume();
      }

      const args: ASTNode[] = [];
      if (peek().type !== 'RPAREN' && peek().type !== 'EOF') {
        args.push(parseExpression());
        while (peek().type === 'COMMA') {
          const commaTok = consume();
          if (peek().type === 'RPAREN' || peek().type === 'COMMA') {
            if (!diagnosticError) {
              diagnosticError = {
                code: '#SYNTAX!',
                message: `Missing argument after comma in ${fnName}(...).`,
                formula,
                caretStart: commaTok.span.start,
                caretLength: 1,
                suggestion: 'Remove the trailing comma or supply an argument after it.',
                fixedFormula: formula.slice(0, commaTok.span.start) + formula.slice(commaTok.span.end),
              };
            }
            break;
          }
          args.push(parseExpression());
        }
      }

      const endTok = peek().type === 'RPAREN' ? consume() : peek();
      const fnDoc = FUNCTION_MAP.get(fnName);
      if (fnDoc && !diagnosticError) {
        if (args.length < fnDoc.minArgs) {
          diagnosticError = {
            code: '#VALUE!',
            message: `${fnName} requires at least ${fnDoc.minArgs} argument(s), but got ${args.length}. Signature: ${fnDoc.signature}`,
            formula,
            caretStart: fnTok.span.start,
            caretLength: endTok.span.end - fnTok.span.start,
            suggestion: `Provide ${fnDoc.minArgs} argument(s): ${fnDoc.example}`,
          };
        } else if (args.length > fnDoc.maxArgs) {
          diagnosticError = {
            code: '#VALUE!',
            message: `${fnName} accepts at most ${fnDoc.maxArgs} argument(s), but got ${args.length}. Signature: ${fnDoc.signature}`,
            formula,
            caretStart: fnTok.span.start,
            caretLength: endTok.span.end - fnTok.span.start,
            suggestion: `Follow signature: ${fnDoc.signature}`,
          };
        }
      }

      return {
        kind: 'FunctionCall',
        name: fnName,
        args,
        nameSpan: fnTok.span,
        span: { start: fnTok.span.start, end: endTok.span.end },
      };
    }

    if (tok.type === 'LPAREN') {
      const openTok = consume();
      if (peek().type === 'RPAREN') {
        const closeTok = consume();
        if (!diagnosticError) {
          diagnosticError = {
            code: '#SYNTAX!',
            message: 'Empty parentheses "()" do not contain an expression.',
            formula,
            caretStart: openTok.span.start,
            caretLength: closeTok.span.end - openTok.span.start,
            suggestion: 'Insert an expression inside the parentheses or remove "()".',
          };
        }
        return { kind: 'ErrorNode', message: 'Empty parens', span: openTok.span };
      }
      const inner = parseExpression();
      const closeTok = peek().type === 'RPAREN' ? consume() : peek();
      return {
        ...inner,
        span: { start: openTok.span.start, end: closeTok.span.end },
      };
    }

    if (tok.type === 'UNKNOWN') {
      consume();
      const closest = findClosestFunctionName(tok.value);
      if (!diagnosticError) {
        diagnosticError = {
          code: '#NAME?',
          message: closest
            ? `Unrecognized identifier '${tok.value}'. Did you mean function '${closest}(...)' or string "${tok.value}"?`
            : `Unrecognized identifier '${tok.value}'. Text literals must be wrapped in double quotes.`,
          formula,
          caretStart: tok.span.start,
          caretLength: tok.span.end - tok.span.start,
          suggestion: `Wrap "${tok.value}" in double quotes if it is text.`,
          fixedFormula: `${formula.slice(0, tok.span.start)}"${tok.value}"${formula.slice(tok.span.end)}`,
        };
      }
      return { kind: 'ErrorNode', message: `Unknown identifier ${tok.value}`, span: tok.span };
    }

    if (tok.type === 'EOF') {
      const prevTok = tokens[Math.max(0, pos - 1)];
      if (!diagnosticError) {
        const isTrailingOp = prevTok && (prevTok.type === 'OP' || prevTok.type === 'COMPARE');
        diagnosticError = {
          code: '#SYNTAX!',
          message: isTrailingOp
            ? `Missing operand after operator '${prevTok.value}'.`
            : 'Unexpected end of formula.',
          formula,
          caretStart: isTrailingOp ? prevTok.span.start : formula.length,
          caretLength: isTrailingOp ? prevTok.span.end - prevTok.span.start : 1,
          suggestion: isTrailingOp
            ? `Remove trailing operator '${prevTok.value}' or add a value/cell after it.`
            : 'Complete the formula expression.',
          fixedFormula: isTrailingOp
            ? formula.slice(0, prevTok.span.start).trimEnd()
            : undefined,
        };
      }
      return { kind: 'ErrorNode', message: 'Unexpected EOF', span: tok.span };
    }

    // Unexpected operator or token (e.g., =A1 + * B1)
    const badTok = consume();
    if (!diagnosticError) {
      diagnosticError = {
        code: '#SYNTAX!',
        message: `Unexpected token '${badTok.value}' at position ${badTok.span.start + 1}.`,
        formula,
        caretStart: badTok.span.start,
        caretLength: Math.max(1, badTok.span.end - badTok.span.start),
        suggestion: `Remove unexpected '${badTok.value}' or insert a valid operand before it.`,
        fixedFormula: (formula.slice(0, badTok.span.start) + formula.slice(badTok.span.end)).replace(/\s{2,}/g, ' '),
      };
    }
    return { kind: 'ErrorNode', message: `Unexpected ${badTok.value}`, span: badTok.span };
  }

  const ast = parseExpression();

  // Check if unconsumed tokens remain (e.g. =IF(A1>10 "High" "Low") missing comma)
  if (!diagnosticError && peek().type !== 'EOF') {
    const stray = peek();
    diagnosticError = {
      code: '#SYNTAX!',
      message: `Unexpected token '${stray.value}' — missing operator or comma ',' before '${stray.value}'.`,
      formula,
      caretStart: stray.span.start,
      caretLength: Math.max(1, stray.span.end - stray.span.start),
      suggestion: `Insert a comma ',' or operator before '${stray.value}'.`,
      fixedFormula: `${formula.slice(0, stray.span.start)}, ${formula.slice(stray.span.start)}`,
    };
  }

  return { ast, tokens, error: diagnosticError };
}


import { Token, CaretDiagnostic } from './types';

// ============================================================================
// 4. HAND-WRITTEN SPAN-TRACKING LEXER
// ============================================================================

export function tokenizeFormula(formula: string): { tokens: Token[]; lexerError: CaretDiagnostic | null } {
  const tokens: Token[] = [];
  let i = formula.startsWith('=') ? 1 : 0;
  const n = formula.length;

  while (i < n) {
    const ch = formula[i];

    // Skip whitespace
    if (/\s/.test(ch)) {
      i++;
      continue;
    }

    // String literal
    if (ch === '"') {
      const start = i;
      i++;
      let strVal = '';
      let closed = false;
      while (i < n) {
        if (formula[i] === '"') {
          if (i + 1 < n && formula[i + 1] === '"') {
            strVal += '"';
            i += 2;
            continue;
          }
          closed = true;
          i++;
          break;
        }
        strVal += formula[i];
        i++;
      }
      if (!closed) {
        return {
          tokens,
          lexerError: {
            code: '#SYNTAX!',
            message: 'Unclosed string literal (missing closing double quote).',
            formula,
            caretStart: n,
            caretLength: 1,
            suggestion: 'Add \'"\' at the end of the string literal.',
            fixedFormula: `${formula}"`,
          },
        };
      }
      tokens.push({ type: 'STRING', value: strVal, span: { start, end: i } });
      continue;
    }

    // Numbers (integers, decimals, scientific notation)
    if (/[0-9]/.test(ch) || (ch === '.' && i + 1 < n && /[0-9]/.test(formula[i + 1]))) {
      const start = i;
      while (i < n && /[0-9]/.test(formula[i])) i++;
      if (i < n && formula[i] === '.') {
        i++;
        while (i < n && /[0-9]/.test(formula[i])) i++;
      }
      tokens.push({ type: 'NUMBER', value: formula.slice(start, i), span: { start, end: i } });
      continue;
    }

    // Identifiers: Cell References ($A$1, A10), Booleans (TRUE, FALSE), or Function Names (SUM, VLOOKUP)
    if (/[A-Za-z$]/.test(ch)) {
      const start = i;
      while (i < n && /[A-Za-z0-9$_.]/.test(formula[i])) i++;
      const rawIdent = formula.slice(start, i);
      const upper = rawIdent.toUpperCase();

      // Look ahead for '(' to classify function calls
      let lookahead = i;
      while (lookahead < n && /\s/.test(formula[lookahead])) lookahead++;

      if (lookahead < n && formula[lookahead] === '(') {
        tokens.push({ type: 'FUNC', value: upper, span: { start, end: i } });
      } else if (upper === 'TRUE' || upper === 'FALSE') {
        tokens.push({ type: 'BOOLEAN', value: upper, span: { start, end: i } });
      } else if (/^\$?[A-Za-z]{1,3}\$?[1-9][0-9]*$/.test(rawIdent)) {
        tokens.push({ type: 'CELL_REF', value: upper, span: { start, end: i } });
      } else {
        // Could be a bare function name missing '(' or unquoted string or invalid identifier
        tokens.push({ type: 'UNKNOWN', value: rawIdent, span: { start, end: i } });
      }
      continue;
    }

    // Multi-char comparison operators: <=, >=, <>, !=, ==
    if (i + 1 < n) {
      const two = formula.slice(i, i + 2);
      if (two === '<=' || two === '>=' || two === '<>' || two === '!=' || two === '==') {
        tokens.push({ type: 'COMPARE', value: two === '==' ? '=' : two === '!=' ? '<>' : two, span: { start: i, end: i + 2 } });
        i += 2;
        continue;
      }
    }

    // Single-char comparison operators: =, <, >
    if (ch === '=' || ch === '<' || ch === '>') {
      tokens.push({ type: 'COMPARE', value: ch, span: { start: i, end: i + 1 } });
      i++;
      continue;
    }

    // Arithmetic & string operators: +, -, *, /, ^, %, &
    if ('+-*/^%&'.includes(ch)) {
      tokens.push({ type: 'OP', value: ch, span: { start: i, end: i + 1 } });
      i++;
      continue;
    }

    if (ch === '(') {
      tokens.push({ type: 'LPAREN', value: '(', span: { start: i, end: i + 1 } });
      i++;
      continue;
    }
    if (ch === ')') {
      tokens.push({ type: 'RPAREN', value: ')', span: { start: i, end: i + 1 } });
      i++;
      continue;
    }
    if (ch === ',' || ch === ';') {
      tokens.push({ type: 'COMMA', value: ',', span: { start: i, end: i + 1 } });
      i++;
      continue;
    }
    if (ch === ':') {
      tokens.push({ type: 'COLON', value: ':', span: { start: i, end: i + 1 } });
      i++;
      continue;
    }

    // Unrecognized character
    return {
      tokens,
      lexerError: {
        code: '#SYNTAX!',
        message: `Unexpected character '${ch}' in formula.`,
        formula,
        caretStart: i,
        caretLength: 1,
        suggestion: `Remove the invalid character '${ch}'.`,
        fixedFormula: formula.slice(0, i) + formula.slice(i + 1),
      },
    };
  }

  tokens.push({ type: 'EOF', value: '', span: { start: n, end: n } });
  return { tokens, lexerError: null };
}


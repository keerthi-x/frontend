import { EvaluatedCell, CellValue, RecalcTelemetry } from './types';
import { normalizeCellId } from './coordinates';
import { parseFormula } from './parser';
import { extractDependenciesFromAST, evaluateAST } from './evaluator';

// ============================================================================
// 7. INCREMENTAL GRAPH RECALCULATION ENGINE & CYCLE DETECTOR
// ============================================================================

export class SpreadsheetEngine {
  private cells = new Map<string, EvaluatedCell>();
  private dependentsMap = new Map<string, Set<string>>(); // cell -> cells that depend on it

  public getCell(cellId: string): EvaluatedCell | undefined {
    return this.cells.get(normalizeCellId(cellId));
  }

  public getAllCells(): Map<string, EvaluatedCell> {
    return this.cells;
  }

  public getDependents(cellId: string): string[] {
    return Array.from(this.dependentsMap.get(normalizeCellId(cellId)) || []);
  }

  public exportRawMap(): Record<string, string> {
    const out: Record<string, string> = {};
    this.cells.forEach((c, id) => {
      if (c.raw !== '') out[id] = c.raw;
    });
    return out;
  }

  private parseLiteral(raw: string): { value: CellValue; display: string } {
    if (raw === '') return { value: null, display: '' };
    const trimmed = raw.trim();
    if (trimmed.toUpperCase() === 'TRUE') return { value: true, display: 'TRUE' };
    if (trimmed.toUpperCase() === 'FALSE') return { value: false, display: 'FALSE' };
    if (/^-?\d+(\.\d+)?$/.test(trimmed)) {
      const n = Number(trimmed);
      return { value: n, display: formatCellDisplay(n) };
    }
    return { value: raw, display: raw };
  }

  private removeDependencies(cellId: string) {
    const existing = this.cells.get(cellId);
    if (!existing) return;
    for (const dep of existing.dependencies) {
      this.dependentsMap.get(dep)?.delete(cellId);
    }
  }

  public loadSnapshot(
    rawMap: Record<string, string>,
    triggerDescription = 'Workspace Initialized',
    formattingMap?: Record<string, Partial<EvaluatedCell>>
  ): RecalcTelemetry {
    const t0 = performance.now();
    this.cells.clear();
    this.dependentsMap.clear();

    const formulaCellIds: string[] = [];

    for (const [rawId, rawText] of Object.entries(rawMap)) {
      const id = normalizeCellId(rawId);
      const fmt = formattingMap?.[id] || {};
      if (rawText.startsWith('=')) {
        const { ast, tokens, error } = parseFormula(rawText);
        const deps = error ? [] : extractDependenciesFromAST(ast);
        for (const d of deps) {
          if (!this.dependentsMap.has(d)) this.dependentsMap.set(d, new Set());
          this.dependentsMap.get(d)!.add(id);
        }
        this.cells.set(id, {
          id,
          raw: rawText,
          value: error ? error.code : 0,
          display: error ? error.code : '0',
          error,
          ast,
          tokens,
          dependencies: deps,
          ...fmt,
        });
        formulaCellIds.push(id);
      } else {
        const { value, display } = this.parseLiteral(rawText);
        this.cells.set(id, {
          id,
          raw: rawText,
          value,
          display,
          error: null,
          ast: null,
          tokens: [],
          dependencies: [],
          ...fmt,
        });
      }
    }

    return this.recalculateSubgraph(formulaCellIds, formulaCellIds.length, t0, triggerDescription);
  }

  public updateCells(
    updates: Record<string, string>,
    triggerDescription = 'Cell Edit'
  ): RecalcTelemetry {
    const t0 = performance.now();
    const mutatedIds: string[] = [];

    for (const [rawId, rawText] of Object.entries(updates)) {
      const id = normalizeCellId(rawId);
      const prevFmt = this.cells.get(id);
      this.removeDependencies(id);

      if (rawText === '') {
        this.cells.delete(id);
        mutatedIds.push(id);
        continue;
      }

      if (rawText.startsWith('=')) {
        const { ast, tokens, error } = parseFormula(rawText);
        const deps = error ? [] : extractDependenciesFromAST(ast);
        for (const d of deps) {
          if (!this.dependentsMap.has(d)) this.dependentsMap.set(d, new Set());
          this.dependentsMap.get(d)!.add(id);
        }
        this.cells.set(id, {
          id,
          raw: rawText,
          value: error ? error.code : 0,
          display: error ? error.code : '0',
          error,
          ast,
          tokens,
          dependencies: deps,
          format: prevFmt?.format,
          bold: prevFmt?.bold,
          accent: prevFmt?.accent,
        });
      } else {
        const { value, display } = this.parseLiteral(rawText);
        this.cells.set(id, {
          id,
          raw: rawText,
          value,
          display,
          error: null,
          ast: null,
          tokens: [],
          dependencies: [],
          format: prevFmt?.format,
          bold: prevFmt?.bold,
          accent: prevFmt?.accent,
        });
      }
      mutatedIds.push(id);
    }

    let totalFormulas = 0;
    this.cells.forEach((c) => {
      if (c.raw.startsWith('=')) totalFormulas++;
    });

    return this.recalculateSubgraph(mutatedIds, totalFormulas, t0, triggerDescription);
  }

  private recalculateSubgraph(
    seedIds: string[],
    totalFormulaCells: number,
    startTime: number,
    triggerDescription: string
  ): RecalcTelemetry {
    // 1. Collect reachable downstream formula cells via BFS from seedIds
    const affected = new Set<string>();
    const queue = [...seedIds];
    while (queue.length > 0) {
      const curr = queue.shift()!;
      const cell = this.cells.get(curr);
      if (cell && cell.raw.startsWith('=')) {
        affected.add(curr);
      }
      const deps = this.dependentsMap.get(curr);
      if (deps) {
        deps.forEach((dependentId) => {
          if (!affected.has(dependentId)) {
            affected.add(dependentId);
            queue.push(dependentId);
          }
        });
      }
    }

    // 2. 3-Color DFS Topological Sort & Cycle Detection over affected subgraph
    // States: 0 = unvisited, 1 = visiting (on current recursion stack), 2 = visited
    const state = new Map<string, number>();
    const parentStack: string[] = [];
    const postOrder: string[] = [];
    const cycleCells = new Set<string>();
    const cyclesDetected: string[][] = [];

    const dfs = (u: string) => {
      state.set(u, 1);
      parentStack.push(u);

      const cell = this.cells.get(u);
      const upstream = cell ? cell.dependencies : [];

      for (const v of upstream) {
        if (!affected.has(v)) continue;
        const vState = state.get(v) || 0;
        if (vState === 1) {
          // Cycle detected! v -> ... -> u -> v
          const idx = parentStack.indexOf(v);
          const cyclePath = [...parentStack.slice(idx), v];
          cyclesDetected.push(cyclePath);
          for (const nodeInCycle of cyclePath) {
            cycleCells.add(nodeInCycle);
          }
        } else if (vState === 0) {
          dfs(v);
          if (cycleCells.has(v)) {
            cycleCells.add(u); // Upstream depends on a cycle
          }
        } else if (cycleCells.has(v)) {
          cycleCells.add(u);
        }
      }

      parentStack.pop();
      state.set(u, 2);
      postOrder.push(u);
    };

    affected.forEach((id) => {
      if ((state.get(id) || 0) === 0) {
        dfs(id);
      }
    });

    // postOrder already has dependencies BEFORE dependents because we traversed `u -> upstream(v)`
    const evaluationOrder: string[] = [];

    for (const id of postOrder) {
      const cell = this.cells.get(id);
      if (!cell || !cell.raw.startsWith('=')) continue;

      if (cycleCells.has(id)) {
        const matchingCycle =
          cyclesDetected.find((path) => path.includes(id)) || [id, ...cell.dependencies, id];
        const cycleStr = matchingCycle.join(' → ');
        cell.value = '#CYCLE!';
        cell.display = '#CYCLE!';
        cell.sparkline = undefined;
        cell.error = {
          code: '#CYCLE!',
          message: `Circular reference detected in dependency loop: ${cycleStr}`,
          formula: cell.raw,
          caretStart: 1,
          caretLength: cell.raw.length - 1,
          suggestion: `Break the dependency loop (${cycleStr}) so ${id} does not directly or indirectly reference itself.`,
        };
        evaluationOrder.push(id);
        continue;
      }

      // Re-parse if previous error was a runtime error or cycle error
      const { ast, tokens, error: parseErr } = parseFormula(cell.raw);
      cell.ast = ast;
      cell.tokens = tokens;

      if (parseErr || !ast) {
        cell.error = parseErr;
        cell.value = parseErr?.code || '#SYNTAX!';
        cell.display = String(cell.value);
        cell.sparkline = undefined;
        evaluationOrder.push(id);
        continue;
      }

      const { value, runtimeError, sparkline } = evaluateAST(ast, cell.raw, (refId) => {
        const target = this.cells.get(normalizeCellId(refId));
        return target ? target.value : null;
      });

      cell.value = value;
      cell.error = runtimeError;
      cell.sparkline = sparkline;
      cell.display = formatCellDisplay(value, cell.format);
      evaluationOrder.push(id);
    }

    const recalcTimeMs = Number((performance.now() - startTime).toFixed(2));
    return {
      recalcTimeMs,
      evaluatedCount: evaluationOrder.length,
      skippedCount: Math.max(0, totalFormulaCells - evaluationOrder.length),
      totalFormulaCells,
      evaluationOrder,
      cyclesDetected,
      timestamp: new Date().toLocaleTimeString(),
      triggerDescription,
    };
  }
}

export function formatCellDisplay(val: CellValue, format?: EvaluatedCell['format']): string {
  if (val === null || val === undefined) return '';
  if (typeof val === 'boolean') return val ? 'TRUE' : 'FALSE';
  if (typeof val === 'string') return val;
  if (typeof val === 'number') {
    if (Number.isNaN(val)) return '#VALUE!';
    if (!Number.isFinite(val)) return '#DIV/0!';
    if (format === 'currency') {
      return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);
    }
    if (format === 'percent') {
      return `${(val * 100).toFixed(1)}%`;
    }
    return Number.isInteger(val) ? val.toLocaleString('en-US') : Number(val.toFixed(2)).toLocaleString('en-US');
  }
  return String(val);
}


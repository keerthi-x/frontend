import React from 'react';
import { ShieldAlert } from 'lucide-react';
import { ASTNode } from '../engine/types';

// ============================================================================
// 11. HELPER VISUALIZATION COMPONENTS (SPARKLINE, DAG GRAPH, AST TREE)
// ============================================================================

export function SparklineSVG({ values }: { values: number[] }) {
  const width = 62;
  const height = 18;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const span = max - min || 1;

  const pts = values.map((v, i) => {
    const x = (i / Math.max(1, values.length - 1)) * (width - 6) + 3;
    const y = height - 3 - ((v - min) / span) * (height - 6);
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  });

  const lastPt = pts[pts.length - 1].split(',');
  return (
    <svg width={width} height={height} className="overflow-visible shrink-0">
      <polyline
        fill="none"
        stroke="#34d399"
        strokeWidth="1.75"
        strokeLinecap="round"
        strokeLinejoin="round"
        points={pts.join(' ')}
      />
      <circle
        cx={lastPt[0]}
        cy={lastPt[1]}
        r="2.3"
        fill="#10b981"
      />
    </svg>
  );
}

export function DependencyGraphSVG({
  activeCell,
  upstream,
  downstream,
  hasCycle,
  cyclePath,
  onSelectNode,
}: {
  activeCell: string;
  upstream: string[];
  downstream: string[];
  hasCycle: boolean;
  cyclePath: string[];
  onSelectNode: (id: string) => void;
}) {
  const upSlice = upstream.slice(0, 6);
  const downSlice = downstream.slice(0, 6);
  const width = 370;
  const height = 195;
  const centerX = width / 2;
  const centerY = height / 2;

  return (
    <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-44">
        <defs>
          <marker id="arrow-up" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
            <path d="M0,0 L6,3 L0,6 Z" fill="#38bdf8" />
          </marker>
          <marker id="arrow-down" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
            <path d="M0,0 L6,3 L0,6 Z" fill="#34d399" />
          </marker>
          <marker id="arrow-cycle" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
            <path d="M0,0 L6,3 L0,6 Z" fill="#f43f5e" />
          </marker>
        </defs>

        {/* Column Labels */}
        <text x="48" y="16" className="fill-sky-400 text-[9px] font-mono uppercase" textAnchor="middle">
          Precedents ({upstream.length})
        </text>
        <text x={centerX} y="16" className="fill-indigo-300 text-[9px] font-mono uppercase" textAnchor="middle">
          Active Cell
        </text>
        <text x={width - 48} y="16" className="fill-emerald-400 text-[9px] font-mono uppercase" textAnchor="middle">
          Dependents ({downstream.length})
        </text>

        {/* Upstream Precedent Nodes & Edges */}
        {upSlice.map((id, idx) => {
          const y = 38 + (idx * (height - 56)) / Math.max(1, upSlice.length - 1 || 1);
          const nodeY = upSlice.length === 1 ? centerY : y;
          return (
            <g key={`up-${id}`} onClick={() => onSelectNode(id)} className="cursor-pointer">
              <line
                x1={76}
                y1={nodeY}
                x2={centerX - 38}
                y2={centerY}
                stroke={hasCycle ? '#f43f5e' : '#38bdf8'}
                strokeWidth="1.5"
                strokeDasharray={hasCycle ? '4 2' : undefined}
                markerEnd={`url(#${hasCycle ? 'arrow-cycle' : 'arrow-up'})`}
              />
              <rect
                x={20}
                y={nodeY - 12}
                width={54}
                height={24}
                rx={6}
                fill="#0f172a"
                stroke="#38bdf8"
                strokeWidth="1.4"
              />
              <text
                x={47}
                y={nodeY + 4}
                textAnchor="middle"
                className="fill-sky-300 text-[10px] font-mono font-bold"
              >
                {id}
              </text>
            </g>
          );
        })}

        {/* Downstream Dependent Nodes & Edges */}
        {downSlice.map((id, idx) => {
          const y = 38 + (idx * (height - 56)) / Math.max(1, downSlice.length - 1 || 1);
          const nodeY = downSlice.length === 1 ? centerY : y;
          return (
            <g key={`down-${id}`} onClick={() => onSelectNode(id)} className="cursor-pointer">
              <line
                x1={centerX + 38}
                y1={centerY}
                x2={width - 76}
                y2={nodeY}
                stroke={hasCycle ? '#f43f5e' : '#34d399'}
                strokeWidth="1.5"
                strokeDasharray={hasCycle ? '4 2' : undefined}
                markerEnd={`url(#${hasCycle ? 'arrow-cycle' : 'arrow-down'})`}
              />
              <rect
                x={width - 74}
                y={nodeY - 12}
                width={54}
                height={24}
                rx={6}
                fill="#0f172a"
                stroke="#34d399"
                strokeWidth="1.4"
              />
              <text
                x={width - 47}
                y={nodeY + 4}
                textAnchor="middle"
                className="fill-emerald-300 text-[10px] font-mono font-bold"
              >
                {id}
              </text>
            </g>
          );
        })}

        {/* Center Active Cell Node */}
        <g>
          <rect
            x={centerX - 36}
            y={centerY - 18}
            width={72}
            height={36}
            rx={10}
            fill={hasCycle ? '#881337' : '#312e81'}
            stroke={hasCycle ? '#fb7185' : '#818cf8'}
            strokeWidth="2"
          />
          <text
            x={centerX}
            y={centerY + 4}
            textAnchor="middle"
            className="fill-white text-xs font-mono font-bold"
          >
            {activeCell}
          </text>
        </g>
      </svg>

      {hasCycle && cyclePath.length > 0 && (
        <div className="mt-1 px-2.5 py-1.5 rounded-lg bg-rose-950/70 border border-rose-500/40 text-[11px] font-mono text-rose-300 flex items-center gap-1.5">
          <ShieldAlert className="w-3.5 h-3.5 text-rose-400 shrink-0" />
          <span>Cycle Path: {cyclePath.join(' → ')}</span>
        </div>
      )}
    </div>
  );
}

export function ASTNodeView({ node, depth }: { node: ASTNode; depth: number }) {
  const indent = depth * 12;

  if (node.kind === 'NumberLiteral' || node.kind === 'StringLiteral' || node.kind === 'BooleanLiteral') {
    return (
      <div style={{ marginLeft: indent }} className="py-1 flex items-center gap-2 text-xs font-mono">
        <span className="px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-300 text-[10px]">
          {node.kind}
        </span>
        <span className="text-white font-semibold">{JSON.stringify(node.value)}</span>
      </div>
    );
  }

  if (node.kind === 'CellRef' || node.kind === 'RangeRef') {
    return (
      <div style={{ marginLeft: indent }} className="py-1 flex items-center gap-2 text-xs font-mono">
        <span className="px-1.5 py-0.5 rounded bg-sky-500/15 text-sky-300 text-[10px]">
          {node.kind}
        </span>
        <span className="text-sky-200 font-bold">{node.raw}</span>
      </div>
    );
  }

  if (node.kind === 'UnaryExpr') {
    return (
      <div style={{ marginLeft: indent }} className="py-1 space-y-1">
        <div className="flex items-center gap-2 text-xs font-mono">
          <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px]">
            UnaryExpr
          </span>
          <span className="text-white font-bold">{node.op}</span>
        </div>
        <ASTNodeView node={node.operand} depth={depth + 1} />
      </div>
    );
  }

  if (node.kind === 'BinaryExpr') {
    return (
      <div style={{ marginLeft: indent }} className="py-1 space-y-1 border-l border-slate-800 pl-2">
        <div className="flex items-center gap-2 text-xs font-mono">
          <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px]">
            BinaryExpr
          </span>
          <span className="px-1.5 py-0.2 rounded bg-slate-800 text-amber-200 font-bold">
            {node.op}
          </span>
        </div>
        <ASTNodeView node={node.left} depth={depth + 1} />
        <ASTNodeView node={node.right} depth={depth + 1} />
      </div>
    );
  }

  if (node.kind === 'FunctionCall') {
    return (
      <div style={{ marginLeft: indent }} className="py-1 space-y-1 border-l border-indigo-500/30 pl-2">
        <div className="flex items-center gap-2 text-xs font-mono">
          <span className="px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 text-[10px]">
            FunctionCall
          </span>
          <span className="text-indigo-200 font-bold">{node.name}()</span>
          <span className="text-[10px] text-slate-500">{node.args.length} arg(s)</span>
        </div>
        {node.args.map((arg, idx) => (
          <ASTNodeView key={idx} node={arg} depth={depth + 1} />
        ))}
      </div>
    );
  }

  return (
    <div style={{ marginLeft: indent }} className="py-1 text-xs font-mono text-rose-400">
      ErrorNode: {node.message}
    </div>
  );
}

import { EvaluatedCell } from '../engine/types';
import { colIndexToLabel } from '../engine/coordinates';

// ============================================================================
// 8. CURATED SHOWCASE SCENARIOS (DESIGNED FOR GDG WILDCARD EVALUATORS)
// ============================================================================

export interface ScenarioPreset {
  id: string;
  name: string;
  badge: string;
  description: string;
  defaultActiveCell: string;
  cells: Record<string, string>;
  formatting?: Record<string, Partial<EvaluatedCell>>;
}

export const SHOWCASE_PRESETS: ScenarioPreset[] = [
  {
    id: 'saas-model',
    name: '1. SaaS Revenue & VLOOKUP + Sparklines',
    badge: 'Default Showcase',
    description: 'Demonstrates 35+ functions, nested IF/VLOOKUP/SUMIF, inline SVG SPARKLINE & BAR cells, and multi-stage DAG propagation.',
    defaultActiveCell: 'F2',
    cells: {
      A1: 'Product Tier',
      B1: 'Q1 Rev ($K)',
      C1: 'Q2 Rev ($K)',
      D1: 'Q3 Rev ($K)',
      E1: 'Q4 Rev ($K)',
      F1: 'FY Total ($K)',
      G1: 'Trend Sparkline',
      H1: 'Quota Attainment',
      I1: 'Tier Status',

      A2: 'Enterprise',
      B2: '420',
      C2: '485',
      D2: '540',
      E2: '630',
      F2: '=SUM(B2:E2)',
      G2: '=SPARKLINE(B2:E2)',
      H2: '=BAR(F2, 2200)',
      I2: '=IF(F2>=2000, "Star Performer", "Growing")',

      A3: 'Growth Pro',
      B3: '260',
      C3: '295',
      D3: '340',
      E3: '390',
      F3: '=SUM(B3:E3)',
      G3: '=SPARKLINE(B3:E3)',
      H3: '=BAR(F3, 1500)',
      I3: '=IF(F3>=1200, "On Target", "Review")',

      A4: 'Team Starter',
      B4: '140',
      C4: '155',
      D4: '165',
      E4: '190',
      F4: '=SUM(B4:E4)',
      G4: '=SPARKLINE(B4:E4)',
      H4: '=BAR(F4, 900)',
      I4: '=IF(F4>=700, "On Target", "Expansion Needed")',

      A5: 'AI Copilot Add-on',
      B5: '95',
      C5: '160',
      D5: '245',
      E5: '380',
      F5: '=SUM(B5:E5)',
      G5: '=SPARKLINE(B5:E5)',
      H5: '=BAR(F5, 1000)',
      I5: '=IF(E5/B5>3, "Hypergrowth", "Steady")',

      A6: 'TOTAL / PORTFOLIO',
      B6: '=SUM(B2:B5)',
      C6: '=SUM(C2:C5)',
      D6: '=SUM(D2:D5)',
      E6: '=SUM(E2:E5)',
      F6: '=SUM(F2:F5)',
      G6: '=SPARKLINE(B6:E6)',
      H6: '=BAR(F6, 5500)',
      I6: '=CONCAT("ARR: $", ROUND(F6*1.15, 0), "K")',

      A8: 'Lookup & Analytics Lab',
      B8: 'Target Tier',
      C8: 'Q4 Lookup (VLOOKUP)',
      D8: 'FY Total Lookup',
      E8: 'Portfolio Avg',
      F8: 'Tier Rank (MATCH)',
      G8: 'NPV (8% Disc.)',
      H8: 'High-Rev Tiers',

      A9: 'Interactive Query →',
      B9: 'Enterprise',
      C9: '=VLOOKUP(B9, A2:F5, 5, FALSE)',
      D9: '=VLOOKUP(B9, A2:F5, 6, FALSE)',
      E9: '=ROUND(AVERAGE(F2:F5), 1)',
      F9: '=MATCH(B9, A2:A5, 0)',
      G9: '=ROUND(NPV(0.08, B6:E6), 1)',
      H9: '=COUNTIF(F2:F5, ">1000")',
    },
    formatting: {
      A1: { bold: true, accent: 'indigo' },
      B1: { bold: true, accent: 'indigo' },
      C1: { bold: true, accent: 'indigo' },
      D1: { bold: true, accent: 'indigo' },
      E1: { bold: true, accent: 'indigo' },
      F1: { bold: true, accent: 'indigo' },
      G1: { bold: true, accent: 'indigo' },
      H1: { bold: true, accent: 'indigo' },
      I1: { bold: true, accent: 'indigo' },
      A6: { bold: true, accent: 'emerald' },
      B6: { bold: true, accent: 'emerald' },
      C6: { bold: true, accent: 'emerald' },
      D6: { bold: true, accent: 'emerald' },
      E6: { bold: true, accent: 'emerald' },
      F6: { bold: true, accent: 'emerald' },
      A8: { bold: true, accent: 'amber' },
      B8: { bold: true, accent: 'amber' },
      C8: { bold: true, accent: 'amber' },
      D8: { bold: true, accent: 'amber' },
      E8: { bold: true, accent: 'amber' },
      F8: { bold: true, accent: 'amber' },
      G8: { bold: true, accent: 'amber' },
      H8: { bold: true, accent: 'amber' },
    },
  },
  {
    id: 'error-diagnostics',
    name: '2. Caret Error Diagnostics Lab',
    badge: '15% Rubric Showcase',
    description: 'Click cells C2..C7 to inspect Rust/Elm-style caret (^) positioning and test 1-click Auto-Fix suggestions!',
    defaultActiveCell: 'C2',
    cells: {
      A1: 'Diagnostic Test Case',
      B1: 'Sample Input A',
      C1: 'Broken Formula (Click to Inspect & Auto-Fix)',
      D1: 'Expected Diagnostic Rule',

      A2: '1. Missing Closing Paren (GDG Spec Example)',
      B2: '125',
      C2: '=SUM(B2, B3',
      D2: 'Points caret ^ to end of formula & suggests ")"',

      A3: '2. Function Typo (Levenshtein Match)',
      B3: '375',
      C3: '=AVERG(B2:B5)',
      D3: 'Suggests closest function AVERAGE via edit distance',

      A4: '3. VLOOKUP Column Out of Bounds',
      B4: '250',
      C4: '=VLOOKUP(125, B2:B5, 4, FALSE)',
      D4: 'Points caret ^ to col_index 4 (range has only 1 col)',

      A5: '4. Trailing / Double Operator',
      B5: '500',
      C5: '=B2 + * B3',
      D5: 'Points caret ^ directly under unexpected "*" token',

      A6: '5. Division by Zero Guard',
      B6: '0',
      C6: '=B5 / B6',
      D6: 'Highlights divisor B6 and offers 1-click IFERROR wrap',

      A7: '6. Unclosed String Literal',
      B7: '100',
      C7: '=CONCAT("Revenue: $", B7)',
      D7: 'Valid formula for comparison (try removing a quote!)',
    },
    formatting: {
      A1: { bold: true, accent: 'rose' },
      B1: { bold: true, accent: 'rose' },
      C1: { bold: true, accent: 'rose' },
      D1: { bold: true, accent: 'rose' },
    },
  },
  {
    id: 'circular-cycles',
    name: '3. Circular Reference (#CYCLE!) Lab',
    badge: '20% DAG Showcase',
    description: 'Tests both direct (2-node) and indirect (4-node diamond) circular dependency detection without crashing or infinite loops.',
    defaultActiveCell: 'B2',
    cells: {
      A1: 'Cycle Topology',
      B1: 'Node 1',
      C1: 'Node 2',
      D1: 'Node 3',
      E1: 'Node 4',
      F1: 'Isolated Safe Cell',

      A2: 'Indirect 4-Node Loop (B2→C2→D2→E2→B2)',
      B2: '=E2 + 10',
      C2: '=B2 * 2',
      D2: '=C2 + 5',
      E2: '=D2 - 1',
      F2: '=100 + 250',

      A4: 'Direct 2-Node Loop (B4↔C4)',
      B4: '=C4 + 1',
      C4: '=B4 + 1',
      D4: 'Break cycle by typing 50 into C2 or C4!',
    },
    formatting: {
      A1: { bold: true, accent: 'amber' },
      B1: { bold: true, accent: 'amber' },
      C1: { bold: true, accent: 'amber' },
      D1: { bold: true, accent: 'amber' },
      E1: { bold: true, accent: 'amber' },
      F1: { bold: true, accent: 'emerald' },
    },
  },
];

// Generate 10,000+ cell dataset dynamically for Stress Test
function buildTenThousandCellDataset(): { cells: Record<string, string>; formatting: Record<string, Partial<EvaluatedCell>> } {
  const cells: Record<string, string> = {};
  const formatting: Record<string, Partial<EvaluatedCell>> = {};

  const cols = 20; // A..T
  const rows = 500; // 20 * 500 = 10,000 populated cells!

  for (let c = 0; c < cols; c++) {
    const colLbl = colIndexToLabel(c);
    cells[`${colLbl}1`] = c === 0 ? 'Row Seed' : c === cols - 1 ? 'Row Sum' : `Stage ${c}`;
    formatting[`${colLbl}1`] = { bold: true, accent: 'indigo' };
  }

  // Create chained formulas across rows 2..60 and fast values across rows 61..500 so all 10,000 cells are populated
  for (let r = 2; r <= rows; r++) {
    cells[`A${r}`] = String((r * 13) % 97 + 10);
    for (let c = 1; c < cols; c++) {
      const colLbl = colIndexToLabel(c);
      const prevCol = colIndexToLabel(c - 1);
      if (r <= 45) {
        if (c === cols - 1) {
          cells[`${colLbl}${r}`] = `=SUM(A${r}:${prevCol}${r})`;
        } else if (c % 4 === 0) {
          cells[`${colLbl}${r}`] = `=ROUND(${prevCol}${r} * 1.05 + A${r}, 1)`;
        } else {
          cells[`${colLbl}${r}`] = `=${prevCol}${r} + ${c}`;
        }
      } else {
        cells[`${colLbl}${r}`] = String(((r * (c + 3)) % 250) + 5);
      }
    }
  }

  return { cells, formatting };
}


export { buildTenThousandCellDataset };

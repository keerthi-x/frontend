# HyperGrid Studio — Compiler-Grade Reactive Spreadsheet Web Application

**Category:** Frontend / Full-Stack Development (Task 2 — GDG Tech Wildcard Entry)  
**Primary Technology:** TypeScript (Strict Mode), React 18, Tailwind CSS  
**Core Engine Dependencies:** **Zero** (100% custom hand-written Lexer, Pratt AST Parser, Evaluator, Bidirectional Dependency Graph, and 2D Windowed Grid Virtualizer)

---

## 1. General Submission Guidelines Compliance Matrix

| Guideline # | Official Requirement | Implementation & Verification in Repository |
| :--- | :--- | :--- |
| **1. Source Code** | Submit a GitHub repository containing complete, readable, and maintainable source code. | Modular, single-responsibility TypeScript architecture under `src/engine/` (`types.ts`, `coordinates.ts`, `lexer.ts`, `parser.ts`, `functions.ts`, `evaluator.ts`, `dag.ts`), `src/data/presets.ts`, and `src/components/`. |
| **2. Setup & Testing** | Include a README with prerequisites, installation, configuration, execution, and testing instructions. | Documented in Section 2 below with copy-pasteable commands for `npm install`, `npm run dev`, `npm run build`, `npm test`, and `npm run benchmark`. |
| **3. Architecture & Decisions** | Document architecture, core implementation decisions, limitations, and any external libraries or assets used. | Detailed in Sections 3, 4, 5, and 6 below, covering parser choice, 3-color DFS cycle extraction, lazy conditional evaluation, and explicit trade-offs. |
| **4. Custom Core Logic** | Do not replace required core logic with a library when the task explicitly requires a custom implementation. | **Zero** external formula parsers (`hyperformula`, `mathjs`, `hot-formula-parser`) or grid libraries (`ag-grid`, `handsontable`, `react-window`) are used. All parsing, evaluation, DAG sorting, and virtualization are written from scratch. |
| **5. Performance & Reliability Evidence** | Provide evidence for performance, reliability, or security claims where the task asks for tests or a report. | Automated zero-dependency test & benchmark runner (`tests/run-tests.mjs`) executes 14 test suites (35+ assertions) and 10,000-cell benchmarks in Node.js (Section 7). |
| **6. Deployment & Build Artifact** | Include a deployment link, build artifact, or demonstration video when required or available. | Includes zero-config `vercel.json` and `netlify.toml` manifests plus the self-contained TypeScript Canvas artifact (`HyperGrid_Spreadsheet_Engine.tsx`). |
| **7. Authorized Systems & Data** | Use only authorized systems, datasets, devices, and lab networks; respect explicit restrictions. | Uses 100% deterministic, in-memory synthetic SaaS financial and mathematical datasets with zero external network calls. |
| **8. Evaluation & Viva Readiness** | Applicants should be prepared to explain their implementation and architectural decisions during evaluation. | Includes Section 9 (Evaluation & Viva Technical Defense Guide) and `INTERVIEW_VIVA_GUIDE.md` in the repository root. |

---

## 2. Prerequisites, Installation, Configuration, Execution & Testing

### 2.1 Prerequisites
* **Node.js:** `v18.0.0` or higher (tested on `v18.20.4` LTS and `v20.x`)
* **Package Manager:** `npm` `v9.0.0+` (or `pnpm` / `yarn`)
* **Browser:** Any modern evergreen browser supporting ES2020 (Chrome, Edge, Firefox, Safari)

### 2.2 Installation
```bash
# Clone the repository and install dependencies
git clone <your-github-repo-url>
cd hypergrid-studio-spreadsheet
npm install
```

### 2.3 Configuration
Grid dimensions and engine thresholds are defined as strongly-typed constants in `src/App.tsx` and `src/engine/coordinates.ts` and require no `.env` secrets to run:

| Constant | Default Value | Purpose |
| :--- | :--- | :--- |
| `TOTAL_ROWS` | `500` | Number of virtualized rows (`1..500`) |
| `TOTAL_COLS` | `26` | Number of virtualized columns (`A..Z`, yielding `13,000` interactive cells) |
| `ROW_HEIGHT` | `30` (px) | Uniform row height for O(1) viewport scroll offset calculation |
| `COL_WIDTH` | `128` (px) | Uniform column width for O(1) horizontal window slicing |
| `maxCells` | `15000` | Safety cap on single range expansion (`expandRange`) to prevent memory exhaustion |

### 2.4 Execution (Development & Production Build)
```bash
# Start Vite hot-reload development server at http://localhost:5173
npm run dev

# Type-check with tsc and bundle production assets into ./dist
npm run build

# Preview production build locally
npm run preview
```

### 2.5 Automated Testing & Empirical Benchmarking
The repository includes a zero-dependency Node.js ES module test and benchmark suite (`tests/run-tests.mjs`) that validates coordinate math, relative/absolute reference shifting, lexer spans, Pratt parser precedence, all 40 functions, caret error diagnostics, cycle isolation, and 10,000-cell recalculation latency:

```bash
# Run the 14 automated unit & integration test suites + 10,000-cell benchmarks
npm test

# Alias for running the empirical benchmark suite
npm run benchmark
```

---

## 3. Repository Structure & Modular Architecture

```text
hypergrid-studio-spreadsheet/
├── README.md                          # Complete submission documentation (Guidelines 1–8)
├── INTERVIEW_VIVA_GUIDE.md            # Deep-dive architectural defense Q&A (Guideline 8)
├── BENCHMARK_AND_TEST_REPORT.md       # Empirical test & 10,000-cell benchmark log (Guideline 5)
├── package.json                       # Scripts: dev, build, preview, test, benchmark
├── tsconfig.json                      # Strict TypeScript compiler configuration
├── vite.config.ts                     # Vite bundler configuration
├── vercel.json                        # Zero-config Vercel deployment manifest
├── netlify.toml                       # Zero-config Netlify deployment manifest
├── index.html                         # Application HTML entry point
├── src/
│   ├── main.tsx                       # React DOM mount
│   ├── index.css                      # Tailwind CSS directives
│   ├── App.tsx                        # Virtualized 2D grid, toolbar, formula bar & X-Ray split-pane
│   ├── engine/
│   │   ├── types.ts                   # ASTNode, Token, SourceSpan, CaretDiagnostic & Telemetry types
│   │   ├── coordinates.ts             # Base-26 column math, range expansion & $A$1 reference shifting
│   │   ├── lexer.ts                   # Hand-written character-span-tracking tokenizer
│   │   ├── parser.ts                  # 7-tier Pratt / recursive-descent AST parser & caret diagnostics
│   │   ├── functions.ts               # Metadata & Levenshtein fuzzy matcher for 40 built-in functions
│   │   ├── evaluator.ts               # Lazy-branching AST evaluator & conditional criterion matcher
│   │   └── dag.ts                     # Bidirectional dependency graph & 3-color DFS topological sort
│   ├── data/
│   │   └── presets.ts                 # 4 evaluator showcase presets & 10,000-cell stress dataset
│   └── components/
│       └── Visualizers.tsx            # SparklineSVG, DependencyGraphSVG & recursive ASTNodeView
└── tests/
    ├── engine-core.mjs                # Pure ES module build of the formula & DAG engine
    └── run-tests.mjs                  # Automated assertion suite & 10,000-cell latency profiler
```

---

## 4. Core Implementation Decisions (Parser, Evaluator, DAG & Virtualization)

### 4.1 Stage 1: Span-Tracking Lexer (`src/engine/lexer.ts`)
* **Decision:** Implement a hand-written character scanner rather than regular-expression token splitting.
* **Rationale:** Every emitted `Token` (`NUMBER`, `STRING`, `BOOLEAN`, `CELL_REF`, `FUNC`, `OP`, `COMPARE`, `LPAREN`, `RPAREN`, `COMMA`, `COLON`, `EOF`) stores its exact 0-indexed `span: { start, end }` in the source formula. When an unclosed string literal or invalid character occurs, the lexer immediately returns a `CaretDiagnostic` pointing to the exact character offset. Lookahead for `(` cleanly disambiguates function identifiers (`SUM(`) from cell coordinates (`A1`, `$B$12`) and boolean literals (`TRUE`, `FALSE`).

### 4.2 Stage 2: 7-Tier Recursive-Descent / Pratt AST Parser (`src/engine/parser.ts`)
* **Decision:** Use a top-down recursive-descent / Pratt operator-precedence parser instead of Dijkstra's Shunting-Yard algorithm.
* **Rationale:** Shunting-yard flattens expressions into Reverse Polish Notation (RPN), making it difficult to preserve exact source spans for nested sub-expressions, validate variadic function arity (`minArgs..maxArgs`), or render an interactive AST tree. Our parser enforces 7 distinct precedence tiers:
  1. `parseComparison`: `=`, `<>`, `<`, `<=`, `>`, `>=`
  2. `parseConcat`: `&` (string concatenation)
  3. `parseAdditive`: `+`, `-`
  4. `parseMultiplicative`: `*`, `/`, `%` (including postfix percentage `50%`)
  5. `parseExponent`: `^` (right-associative via recursive call to `parseExponent`)
  6. `parseUnary`: unary prefix `+x`, `-x`
  7. `parsePrimary`: literals, `CellRef`, `RangeRef` (`A1:B10`), parenthesized expressions, and nested `FunctionCall` nodes.

### 4.3 Stage 3: Rust/Elm-Style Caret Error Diagnostics & Levenshtein Auto-Fix
* **Decision:** Combine structural pre-checks, parser span recovery, and **Levenshtein edit-distance matching** (`src/engine/functions.ts`) to produce actionable repair suggestions.
* **Rationale:** The GDG problem statement specifically highlights human-friendly caret (`^`) diagnostics:
  ```text
  Formula: =SUM(A1, B2
  Error: Missing closing parenthesis.
  =SUM(A1, B2
             ^
  Suggestion: Add ')' at the end of the formula.
  ```
  Our engine not only reproduces this exact diagnostic format in monospace, but also synthesizes a deterministic `fixedFormula` (`=SUM(A1, B2)`) wired to a 1-click **"Apply Fix"** button. Furthermore, if a user mistypes a function name (e.g. `=VLLOKUP(A1, B1:C5, 2, FALSE)` or `=AVERG(B2:B5)`), the parser computes the Levenshtein distance against all 40 supported functions, underlines the typo `^~~~~~~`, asks `Did you mean 'VLOOKUP'?`, and offers a 1-click rewrite.

### 4.4 Stage 4: Incremental Dependency Graph (DAG) & 3-Color DFS Cycle Detection (`src/engine/dag.ts`)
* **Decision:** Maintain bidirectional adjacency maps (`dependencies: string[]` per cell and `dependentsMap: Map<string, Set<string>>`) paired with **BFS Downstream Cone Pruning** and **3-Color DFS Topological Sort**.
* **Rationale:**
  1. **Zero Wasted Evaluations:** When cell `X` is edited, a Breadth-First Search (BFS) over `dependentsMap` collects *only* the formula cells transitively reachable from `X`. All other formula cells in the sheet are skipped (`skippedCount`).
  2. **Exact Cycle Path Extraction:** Standard Kahn's indegree algorithm detects that a cycle exists when visited nodes < total nodes, but it does not directly yield the ordered cycle path. By running a 3-color DFS (`0 = WHITE/unvisited`, `1 = GRAY/on recursion stack`, `2 = BLACK/completed`) over the affected subgraph, any edge targeting a `GRAY (1)` node immediately slices `parentStack` to extract the exact loop (e.g. `B2 → C2 → D2 → E2 → B2`). All cells in or downstream of the cycle are marked `#CYCLE!` in O(V + E) time without infinite recursion.

### 4.5 Stage 5: Lazy Conditional Evaluation & 2D Windowed Virtualization
* **Lazy Branching (`src/engine/evaluator.ts`):** `IF`, `IFS`, and `IFERROR` evaluate their condition first and lazily evaluate *only* the active branch. Consequently, `=IF(B2=0, 0, A2/B2)` safely evaluates to `0` when `B2` is `0` instead of eagerly triggering `#DIV/0!`.
* **2D Windowed Grid (`src/App.tsx`):** Rather than mounting `13,000` DOM nodes (`500 rows × 26 cols`), the scroll container computes `startRow..endRow` and `startCol..endCol` from `scrollTop`, `scrollLeft`, `viewportSize`, and a 4-row/2-column overscan buffer. Only `~150` cell DOM nodes exist at any instant (a **98.8% DOM reduction**).

---

## 5. Known Limitations & Engineering Trade-Offs (Guideline 3)

1. **Single-Worksheet Coordinate Space:** Formulas reference cells (`A1..Z500`) within a single active worksheet rather than multi-tab cross-sheet references (`Sheet2!A1:B10`).
2. **Uniform Row & Column Geometry for O(1) Virtualization:** Rows (`30px`) and columns (`128px`) use uniform dimensions so viewport index calculation (`Math.floor(scrollTop / ROW_HEIGHT)`) is O(1) without requiring a Fenwick tree / prefix-sum array during rapid scrolling.
3. **IEEE-754 Double-Precision Floating Point:** Arithmetic uses standard JavaScript 64-bit floats (`number`). Financial calculations requiring exact fixed-point rounding should use the built-in `ROUND(value, digits)` function.
4. **In-Memory Event-Sourced State:** The 30-revision Time-Travel Undo/Redo history is stored in memory for sub-millisecond snapshot switching rather than persisted to an external backend database.

---

## 6. External Libraries & Assets Used (Guidelines 3 & 4)

| Package | Version | Role in Application | Replaces Core Task Logic? |
| :--- | :--- | :--- | :--- |
| `react` / `react-dom` | `^18.3.1` | Declarative UI component rendering and state hooks | **No** (Allowed frontend framework) |
| `lucide-react` | `^0.454.0` | Clean SVG toolbar and diagnostic icons | **No** (UI iconography only) |
| `tailwindcss` | `^3.4.14` | Utility CSS classes for dark-mode layout and responsive split-pane | **No** (Styling only) |
| `typescript` / `vite` | `^5.6.3` | Static type checking and local dev/production bundling | **No** (Build tooling only) |

> **Certification of Custom Core Implementation (Guideline 4):** Zero third-party spreadsheet engines, expression parsers, DAG solvers, or virtualization libraries are used anywhere in this repository.

---

## 7. Empirical Performance & Reliability Evidence (Guideline 5)

Executing `npm test` (`node tests/run-tests.mjs`) runs 14 automated verification suites and 3 empirical benchmarks on a 10,000-cell populated dataset (`500 rows × 20 columns`, containing `836` chained formulas):

```text
======================================================================
 HYPERGRID STUDIO — AUTOMATED UNIT TEST & EMPIRICAL BENCHMARK SUITE
======================================================================
  [PASS] 1. Column label <-> index bijection (A..ZZ) (0.165 ms)
  [PASS] 2. Relative, mixed, and absolute ($A$1) reference shifting on drag-to-fill (0.696 ms)
  [PASS] 3. Range expansion and inverted range detection (B5:A1) (0.706 ms)
  [PASS] 4. Span-tracking lexer records exact [start, end] offsets (2.623 ms)
  [PASS] 5. Pratt parser operator precedence (* before +, right-associative ^, unary -) (24.759 ms)
  [PASS] 6. Catalog contains >= 30 functions (40 verified) (0.081 ms)
  [PASS] 7. Math & Statistical functions (SUM, AVERAGE, MIN, MAX, MEDIAN, STDEV, ROUND, FLOOR, CEIL, SQRT, POWER, MOD, PRODUCT) (5.040 ms)
  [PASS] 8. Logical & Lazy Branching functions (IF, IFS, AND, OR, NOT, XOR, IFERROR) (2.445 ms)
  [PASS] 9. Lookup & Reference functions (VLOOKUP, HLOOKUP, INDEX, MATCH, CHOOSE, COUNTBLANK) (0.867 ms)
  [PASS] 10. Conditional Aggregation & Text functions (COUNTIF, SUMIF, AVERAGEIF, CONCAT, LEN, UPPER, LOWER, TRIM, NPV, SPARKLINE, BAR) (1.649 ms)
  [PASS] 11. Caret Diagnostics: Missing closing parenthesis matches GDG prompt example (0.238 ms)
  [PASS] 12. Caret Diagnostics: Levenshtein fuzzy function match (=VLLOKUP -> VLOOKUP) (1.303 ms)
  [PASS] 13. Direct & Indirect Circular Reference (#CYCLE!) isolation without infinite loops (0.437 ms)
  [PASS] 14. Incremental DAG recalculates ONLY affected downstream subgraph (0.841 ms)

----------------------------------------------------------------------
 EMPIRICAL PERFORMANCE BENCHMARKS (10,000 POPULATED CELLS)
----------------------------------------------------------------------
  * Benchmark 1 — 10,000-Cell Cold Load & DAG Build (836 formulas): 142.22 ms
  * Benchmark 2 — Isolated Cell Edit (0 formulas affected, 836 skipped): 1.309 ms
  * Benchmark 3 — 19-Stage Chained Row Cascade (19 evaluated, 817 skipped): 1.858 ms
======================================================================
 ALL 14 AUTOMATED TESTS & BENCHMARKS PASSED SUCCESSFULLY!
======================================================================
```

---

## 8. Complete Documentation of Supported Spreadsheet Functions (40 Functions)

| # | Function | Category | Signature | Description & Example |
| :--- | :--- | :--- | :--- | :--- |
| 1 | `SUM` | Math | `SUM(v1, [v2, ...])` | Sums numeric values across cells, ranges, or nested expressions (`=SUM(B2:E2)`). |
| 2 | `AVERAGE` | Math | `AVERAGE(v1, [v2, ...])` | Computes arithmetic mean of numeric values (`=AVERAGE(B2:E2)`). |
| 3 | `MIN` | Math | `MIN(v1, [v2, ...])` | Returns minimum numeric value (`=MIN(B2:E2)`). |
| 4 | `MAX` | Math | `MAX(v1, [v2, ...])` | Returns maximum numeric value (`=MAX(B2:E2)`). |
| 5 | `ABS` | Math | `ABS(number)` | Returns absolute value (`=ABS(-42.5)`). |
| 6 | `ROUND` | Math | `ROUND(number, [digits])` | Rounds to specified decimal places (`=ROUND(3.14159, 2)`). |
| 7 | `FLOOR` | Math | `FLOOR(number, [sig])` | Rounds down toward zero to nearest multiple of significance (`=FLOOR(47.8, 5)`). |
| 8 | `CEIL` | Math | `CEIL(number, [sig])` | Rounds up to nearest multiple of significance (`=CEIL(42.1, 1)`). |
| 9 | `SQRT` | Math | `SQRT(number)` | Returns positive square root; returns `#VALUE!` if negative (`=SQRT(144)`). |
| 10 | `POWER` | Math | `POWER(base, exponent)` | Raises `base` to `exponent` (`=POWER(2, 10)`). |
| 11 | `MOD` | Math | `MOD(dividend, divisor)` | Returns remainder after division; `#DIV/0!` if divisor is `0` (`=MOD(17, 5)`). |
| 12 | `PRODUCT` | Math | `PRODUCT(v1, [v2, ...])` | Multiplies all numeric values in range (`=PRODUCT(B2:B5)`). |
| 13 | `IF` | Logic | `IF(cond, true_val, [false_val])` | Lazily evaluates matching branch (`=IF(F2>=2000, "Star", "Growing")`). |
| 14 | `IFS` | Logic | `IFS(c1, v1, [c2, v2, ...])` | Evaluates multiple condition pairs sequentially (`=IFS(B2>90, "A", TRUE, "B")`). |
| 15 | `AND` | Logic | `AND(log1, [log2, ...])` | Returns `TRUE` if all arguments are truthy (`=AND(B2>0, C2<100)`). |
| 16 | `OR` | Logic | `OR(log1, [log2, ...])` | Returns `TRUE` if any argument is truthy (`=OR(B2>100, C2>100)`). |
| 17 | `NOT` | Logic | `NOT(logical)` | Negates boolean argument (`=NOT(B2=0)`). |
| 18 | `XOR` | Logic | `XOR(log1, [log2, ...])` | Exclusive OR across arguments (`=XOR(TRUE, FALSE)`). |
| 19 | `IFERROR` | Logic | `IFERROR(value, fallback)` | Returns `fallback` if `value` evaluates to any `#ERROR!` (`=IFERROR(B5/B6, 0)`). |
| 20 | `VLOOKUP` | Lookup | `VLOOKUP(key, range, col_idx, [sorted])` | Vertical lookup in leftmost column of `range` (`=VLOOKUP(B9, A2:F5, 5, FALSE)`). |
| 21 | `HLOOKUP` | Lookup | `HLOOKUP(key, range, row_idx, [sorted])` | Horizontal lookup in top row of `range` (`=HLOOKUP("Q2", B1:E5, 2, FALSE)`). |
| 22 | `INDEX` | Lookup | `INDEX(range, row_num, [col_num])` | Returns cell at 1-based `(row, col)` offset in `range` (`=INDEX(A2:F5, 2, 3)`). |
| 23 | `MATCH` | Lookup | `MATCH(key, range, [type])` | Returns 1-based relative index of `key` in `range` (`=MATCH(B9, A2:A5, 0)`). |
| 24 | `CHOOSE` | Lookup | `CHOOSE(index, v1, [v2, ...])` | Selects `index`-th value from argument list (`=CHOOSE(2, "Low", "Med", "High")`). |
| 25 | `COUNTBLANK` | Lookup | `COUNTBLANK(range)` | Counts empty cells in `range` (`=COUNTBLANK(B2:B10)`). |
| 26 | `COUNT` | Statistical | `COUNT(v1, [v2, ...])` | Counts numeric values across arguments/ranges (`=COUNT(B2:E5)`). |
| 27 | `COUNTA` | Statistical | `COUNTA(v1, [v2, ...])` | Counts non-empty cells across arguments/ranges (`=COUNTA(A2:A5)`). |
| 28 | `COUNTIF` | Statistical | `COUNTIF(range, criterion)` | Counts cells matching criterion string (`=COUNTIF(F2:F5, ">1000")`). |
| 29 | `SUMIF` | Statistical | `SUMIF(range, criterion, [sum_range])` | Sums cells where criterion matches (`=SUMIF(B2:B5, ">150", F2:F5)`). |
| 30 | `AVERAGEIF` | Statistical | `AVERAGEIF(range, criterion, [avg_range])` | Averages cells where criterion matches (`=AVERAGEIF(B2:B5, ">150")`). |
| 31 | `MEDIAN` | Statistical | `MEDIAN(v1, [v2, ...])` | Computes middle value of sorted numeric dataset (`=MEDIAN(B2:E2)`). |
| 32 | `STDEV` | Statistical | `STDEV(v1, [v2, ...])` | Computes sample standard deviation (`=STDEV(B2:E2)`). |
| 33 | `CONCAT` | Text | `CONCAT(t1, [t2, ...])` | Concatenates strings and values (`=CONCAT("ARR: $", F6, "K")`). |
| 34 | `LEN` | Text | `LEN(text)` | Returns character count (`=LEN(A2)`). |
| 35 | `UPPER` | Text | `UPPER(text)` | Converts string to uppercase (`=UPPER(A2)`). |
| 36 | `LOWER` | Text | `LOWER(text)` | Converts string to lowercase (`=LOWER(A2)`). |
| 37 | `TRIM` | Text | `TRIM(text)` | Normalizes whitespace (`=TRIM(A2)`). |
| 38 | `SPARKLINE` | Visual & Finance | `SPARKLINE(range)` | Renders inline SVG trendline inside cell & returns period growth % (`=SPARKLINE(B2:E2)`). |
| 39 | `BAR` | Visual & Finance | `BAR(value, max_value)` | Renders inline proportional bar inside cell & returns % attainment (`=BAR(F2, 2200)`). |
| 40 | `NPV` | Visual & Finance | `NPV(rate, cashflow_range)` | Computes Net Present Value at discount `rate` (`=NPV(0.08, B6:E6)`). |

---

## 9. Evaluation & Viva Technical Defense Guide (Guideline 8)

During evaluation, reviewers frequently ask applicants to explain and defend their internal implementation. Here are concise answers grounded directly in this codebase:

1. **"How does your parser handle operator precedence and right-associative exponentiation like `=2^3^2`?"**
   * *Answer:* In `src/engine/parser.ts`, each precedence tier is a distinct mutually recursive function (`parseComparison` → `parseConcat` → `parseAdditive` → `parseMultiplicative` → `parseExponent` → `parseUnary` → `parsePrimary`). Binary `+`, `-`, `*`, and `/` use iterative `while` loops (making them left-associative, so `10 - 3 - 2 = (10 - 3) - 2 = 5`), whereas `parseExponent` recursively calls `parseExponent()` on its right-hand operand, making `2 ^ 3 ^ 2` evaluate as `2 ^ (3 ^ 2) = 512`.
2. **"How do you avoid recalculating all 10,000 cells when a single cell changes?"**
   * *Answer:* In `src/engine/dag.ts`, `SpreadsheetEngine` stores a reverse adjacency map (`dependentsMap: Map<CellId, Set<CellId>>`). When a user edits `A2`, `recalculateSubgraph` starts a BFS queue seeded only with `['A2']` and collects only transitive downstream dependents. Formulas outside that cone are never parsed or evaluated (`skippedCount`).
3. **"How does your engine detect indirect circular references like `A1 -> B1 -> C1 -> A1` without freezing the browser?"**
   * *Answer:* Over the affected subgraph, we run a 3-color Depth-First Search (`state`: `0 = unvisited`, `1 = visiting/on current call stack`, `2 = visited`). If a node `u` traverses an upstream dependency `v` whose state is `1`, we have found a back-edge in the active recursion stack. We slice `parentStack` from `v` to `u` to record the exact cycle chain (`A1 → B1 → C1 → A1`), mark every cell in the cycle with `#CYCLE!`, and never recurse into `v` again.
4. **"How does drag-to-fill shift relative references (`B2`) while keeping `$B$2` fixed?"**
   * *Answer:* In `src/engine/coordinates.ts`, `shiftFormulaReferences(formula, dCol, dRow)` matches cell tokens with `/(\$?)([A-Z]{1,3})(\$?)([1-9][0-9]*)(?!\s*\()/gi`. If `$` precedes the column (`absCol`), `dCol` is ignored; if `$` precedes the row (`absRow`), `dRow` is ignored. Otherwise the 0-based column/row index is shifted by `(dCol, dRow)` and re-encoded via `colIndexToLabel`.
5. **"How do you compute exact caret (`^`) positions for error reporting?"**
   * *Answer:* Every token produced by `tokenizeFormula` carries `span: { start, end }` indexing into the original raw formula string. Every AST node inherits the merged `[start, end]` span of its children. Whether an error occurs at lex time (unclosed quote), parse time (missing `)`, unknown function `VLLOKUP`), or evaluation time (`#DIV/0!` divisor span or out-of-bounds `VLOOKUP` column index argument `n.args[2].span`), the diagnostic renders `' '.repeat(caretStart) + '^'.repeat(caretLength)` directly underneath the offending token.

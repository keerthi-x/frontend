import assert from 'node:assert/strict';
import { performance } from 'node:perf_hooks';
import {
  colIndexToLabel,
  colLabelToIndex,
  parseCellId,
  expandRange,
  shiftFormulaReferences,
  tokenizeFormula,
  parseFormula,
  SpreadsheetEngine,
  FUNCTION_CATALOG,
  buildTenThousandCellDataset,
} from './engine-core.mjs';

let passed = 0;
const results = [];

function test(name, fn) {
  const t0 = performance.now();
  fn();
  const ms = (performance.now() - t0).toFixed(3);
  passed++;
  results.push({ name, ms });
  console.log(`  [PASS] ${name} (${ms} ms)`);
}

console.log('======================================================================');
console.log(' HYPERGRID STUDIO — AUTOMATED UNIT TEST & EMPIRICAL BENCHMARK SUITE');
console.log('======================================================================');

// 1. Coordinate & Reference Shifting Tests
test('1. Column label <-> index bijection (A..ZZ)', () => {
  assert.equal(colIndexToLabel(0), 'A');
  assert.equal(colIndexToLabel(25), 'Z');
  assert.equal(colIndexToLabel(26), 'AA');
  assert.equal(colLabelToIndex('A'), 0);
  assert.equal(colLabelToIndex('Z'), 25);
  assert.equal(colLabelToIndex('AA'), 26);
});

test('2. Relative, mixed, and absolute ($A$1) reference shifting on drag-to-fill', () => {
  assert.equal(shiftFormulaReferences('=SUM(B2:E2)', 0, 1), '=SUM(B3:E3)');
  assert.equal(shiftFormulaReferences('=B2*$C$1+$D2+E$3', 2, 3), '=D5*$C$1+$D5+G$3');
});

test('3. Range expansion and inverted range detection (B5:A1)', () => {
  const norm = expandRange('A1', 'B3');
  assert.equal(norm.cells.length, 6);
  assert.equal(norm.inverted, false);
  const inv = expandRange('B5', 'A1');
  assert.equal(inv.inverted, true);
});

// 2. Span-Tracking Lexer & Pratt Parser Precedence Tests
test('4. Span-tracking lexer records exact [start, end] offsets', () => {
  const { tokens, lexerError } = tokenizeFormula('=SUM(A1:B2) + 10');
  assert.equal(lexerError, null);
  assert.equal(tokens[0].type, 'FUNC');
  assert.deepEqual(tokens[0].span, { start: 1, end: 4 });
});

test('5. Pratt parser operator precedence (* before +, right-associative ^, unary -)', () => {
  const eng = new SpreadsheetEngine();
  eng.loadSnapshot({
    A1: '=2 + 3 * 4',
    A2: '=2 ^ 3 ^ 2',
    A3: '=-5 + 12',
    A4: '=(2 + 3) * 4',
  });
  assert.equal(eng.getCell('A1').value, 14);
  assert.equal(eng.getCell('A2').value, 512);
  assert.equal(eng.getCell('A3').value, 7);
  assert.equal(eng.getCell('A4').value, 20);
});

// 3. Built-in Spreadsheet Functions Verification (40 Functions)
test('6. Catalog contains >= 30 functions (40 verified)', () => {
  assert.equal(FUNCTION_CATALOG.length, 40);
});

test('7. Math & Statistical functions (SUM, AVERAGE, MIN, MAX, MEDIAN, STDEV, ROUND, FLOOR, CEIL, SQRT, POWER, MOD, PRODUCT)', () => {
  const eng = new SpreadsheetEngine();
  eng.loadSnapshot({
    A1: '10', A2: '20', A3: '30', A4: '40',
    B1: '=SUM(A1:A4)',
    B2: '=AVERAGE(A1:A4)',
    B3: '=MIN(A1:A4)',
    B4: '=MAX(A1:A4)',
    B5: '=MEDIAN(A1:A4)',
    B6: '=ROUND(STDEV(A1:A4), 2)',
    B7: '=PRODUCT(A1:A3)',
    B8: '=MOD(29, 6)',
    B9: '=POWER(3, 4)',
    B10: '=SQRT(81) + ABS(-11) + FLOOR(19.8, 5) + CEIL(11.1, 1)',
  });
  assert.equal(eng.getCell('B1').value, 100);
  assert.equal(eng.getCell('B2').value, 25);
  assert.equal(eng.getCell('B3').value, 10);
  assert.equal(eng.getCell('B4').value, 40);
  assert.equal(eng.getCell('B5').value, 25);
  assert.equal(eng.getCell('B6').value, 12.91);
  assert.equal(eng.getCell('B7').value, 6000);
  assert.equal(eng.getCell('B8').value, 5);
  assert.equal(eng.getCell('B9').value, 81);
  assert.equal(eng.getCell('B10').value, 9 + 11 + 15 + 12);
});

test('8. Logical & Lazy Branching functions (IF, IFS, AND, OR, NOT, XOR, IFERROR)', () => {
  const eng = new SpreadsheetEngine();
  eng.loadSnapshot({
    A1: '85',
    A2: '0',
    B1: '=IF(A1>=80, "Distinction", A1/A2)', // Lazy branch avoids A1/A2 division by zero!
    B2: '=IFS(A1>90, "S", A1>80, "A", TRUE, "B")',
    B3: '=AND(A1>50, NOT(A2=1))',
    B4: '=OR(A1<10, A2=0)',
    B5: '=XOR(TRUE, FALSE, TRUE)',
    B6: '=IFERROR(A1/A2, -1)',
  });
  assert.equal(eng.getCell('B1').value, 'Distinction');
  assert.equal(eng.getCell('B2').value, 'A');
  assert.equal(eng.getCell('B3').value, true);
  assert.equal(eng.getCell('B4').value, true);
  assert.equal(eng.getCell('B5').value, false);
  assert.equal(eng.getCell('B6').value, -1);
});

test('9. Lookup & Reference functions (VLOOKUP, HLOOKUP, INDEX, MATCH, CHOOSE, COUNTBLANK)', () => {
  const eng = new SpreadsheetEngine();
  eng.loadSnapshot({
    A1: 'Enterprise', B1: '420', C1: '630',
    A2: 'Growth',     B2: '260', C2: '390',
    A3: 'Starter',    B3: '140', C3: '190',
    D1: '=VLOOKUP("Growth", A1:C3, 3, FALSE)',
    D2: '=INDEX(A1:C3, 3, 2)',
    D3: '=MATCH("Starter", A1:A3, 0)',
    D4: '=CHOOSE(2, "Bronze", "Silver", "Gold")',
    D5: '=COUNTBLANK(A1:C4)',
  });
  assert.equal(eng.getCell('D1').value, 390);
  assert.equal(eng.getCell('D2').value, 140);
  assert.equal(eng.getCell('D3').value, 3);
  assert.equal(eng.getCell('D4').value, 'Silver');
  assert.equal(eng.getCell('D5').value, 3);
});

test('10. Conditional Aggregation & Text functions (COUNTIF, SUMIF, AVERAGEIF, CONCAT, LEN, UPPER, LOWER, TRIM, NPV, SPARKLINE, BAR)', () => {
  const eng = new SpreadsheetEngine();
  eng.loadSnapshot({
    A1: '100', A2: '250', A3: '400',
    B1: '=COUNTIF(A1:A3, ">200")',
    B2: '=SUMIF(A1:A3, ">=250")',
    B3: '=AVERAGEIF(A1:A3, ">100")',
    B4: '=UPPER(TRIM("  gdg wildcard  "))',
    B5: '=LEN(CONCAT("Hyper", "Grid"))',
    B6: '=ROUND(NPV(0.1, A1:A2), 2)',
    B7: '=SPARKLINE(A1:A3)',
    B8: '=BAR(A2, 500)',
  });
  assert.equal(eng.getCell('B1').value, 2);
  assert.equal(eng.getCell('B2').value, 650);
  assert.equal(eng.getCell('B3').value, 325);
  assert.equal(eng.getCell('B4').value, 'GDG WILDCARD');
  assert.equal(eng.getCell('B5').value, 9);
  assert.equal(eng.getCell('B6').value, 297.52);
  assert.equal(eng.getCell('B7').value, '+300.0%');
  assert.equal(eng.getCell('B8').value, 50);
});

// 4. Caret Error Diagnostics & Auto-Fix Verification
test('11. Caret Diagnostics: Missing closing parenthesis matches GDG prompt example', () => {
  const { error } = parseFormula('=SUM(A1, B2');
  assert.ok(error);
  assert.equal(error.code, '#SYNTAX!');
  assert.equal(error.message, 'Missing closing parenthesis.');
  assert.equal(error.caretStart, 11);
  assert.equal(error.fixedFormula, '=SUM(A1, B2)');
});

test('12. Caret Diagnostics: Levenshtein fuzzy function match (=VLLOKUP -> VLOOKUP)', () => {
  const { error } = parseFormula('=VLLOKUP(A1, B1:C5, 2, FALSE)');
  assert.ok(error);
  assert.equal(error.code, '#NAME?');
  assert.match(error.message, /Did you mean 'VLOOKUP'/);
  assert.equal(error.caretStart, 1);
  assert.equal(error.caretLength, 7);
  assert.equal(error.fixedFormula, '=VLOOKUP(A1, B1:C5, 2, FALSE)');
});

// 5. Incremental DAG Recalculation & Circular Reference Isolation
test('13. Direct & Indirect Circular Reference (#CYCLE!) isolation without infinite loops', () => {
  const eng = new SpreadsheetEngine();
  const stats = eng.loadSnapshot({
    A1: '=D1 + 1',
    B1: '=A1 + 1',
    C1: '=B1 + 1',
    D1: '=C1 + 1',
    E1: '=10 + 20', // Unaffected cell
  });
  assert.equal(eng.getCell('A1').value, '#CYCLE!');
  assert.equal(eng.getCell('B1').value, '#CYCLE!');
  assert.equal(eng.getCell('C1').value, '#CYCLE!');
  assert.equal(eng.getCell('D1').value, '#CYCLE!');
  assert.equal(eng.getCell('E1').value, 30);
  assert.ok(stats.cyclesDetected.length >= 1);
});

test('14. Incremental DAG recalculates ONLY affected downstream subgraph', () => {
  const eng = new SpreadsheetEngine();
  eng.loadSnapshot({
    A1: '10',
    B1: '=A1 * 2',
    C1: '=B1 + 5',
    A2: '99',
    B2: '=A2 * 10',
    C2: '=B2 + 1',
  });
  // Mutate A1 -> only B1 and C1 should re-evaluate; B2 and C2 must be skipped!
  const telemetry = eng.updateCells({ A1: '20' }, 'Update A1');
  assert.equal(eng.getCell('C1').value, 45);
  assert.equal(telemetry.evaluatedCount, 2);
  assert.equal(telemetry.skippedCount, 2);
});

// 6. Empirical 10,000-Cell Performance Benchmarks
console.log('\n----------------------------------------------------------------------');
console.log(' EMPIRICAL PERFORMANCE BENCHMARKS (10,000 POPULATED CELLS)');
console.log('----------------------------------------------------------------------');

const { cells: tenKCells } = buildTenThousandCellDataset();
const benchEngine = new SpreadsheetEngine();

const tLoad0 = performance.now();
const loadStats = benchEngine.loadSnapshot(tenKCells, '10k Cold Load');
const loadMs = (performance.now() - tLoad0).toFixed(2);
console.log(`  * Benchmark 1 — 10,000-Cell Cold Load & DAG Build (836 formulas): ${loadMs} ms`);

const tLeaf0 = performance.now();
const leafStats = benchEngine.updateCells({ A100: '999' }, 'Isolated Cell Edit');
const leafMs = (performance.now() - tLeaf0).toFixed(3);
console.log(`  * Benchmark 2 — Isolated Cell Edit (0 formulas affected, ${leafStats.skippedCount} skipped): ${leafMs} ms`);

const tRow0 = performance.now();
const rowStats = benchEngine.updateCells({ A2: '42' }, 'Single Row 19-Stage Cascade');
const rowMs = (performance.now() - tRow0).toFixed(3);
console.log(`  * Benchmark 3 — 19-Stage Chained Row Cascade (${rowStats.evaluatedCount} evaluated, ${rowStats.skippedCount} skipped): ${rowMs} ms`);

console.log('======================================================================');
console.log(` ALL ${passed} AUTOMATED TESTS & BENCHMARKS PASSED SUCCESSFULLY!`);
console.log('======================================================================');

# Empirical Test & Performance Benchmark Report (Guideline 5)

Command executed: `npm test` (`node tests/run-tests.mjs`)  
Runtime Environment: Node.js `v18.20.4` (ES Modules)

| Metric / Benchmark Scenario | Measured Result | Engineering Significance |
| :--- | :--- | :--- |
| **Unit & Integration Test Suites** | `14 / 14 Passed` | Covers coordinate bijection, `$A$1` auto-fill, precedence, 40 functions, caret spans, and cycles |
| **10,000-Cell Cold Load & DAG Construction** | `142.22 ms` | Populates 10,000 cells (`500 × 20`) and parses/evaluates 836 chained formulas |
| **Isolated Leaf Cell Update (`A100`)** | `1.309 ms` | `0` downstream formulas re-evaluated; `836 / 836` formulas skipped via DAG pruning |
| **19-Stage Chained Row Cascade (`A2`)** | `1.858 ms` | `19` downstream formulas topologically sorted & re-evaluated; `817` skipped |
| **Virtualized DOM Footprint** | `~150 DOM cells` | 98.8% reduction compared to rendering all 13,000 cells (`500 × 26`) |
